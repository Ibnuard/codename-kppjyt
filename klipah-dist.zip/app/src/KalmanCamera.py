"""
KalmanCamera - Kalman filter-based camera controller for smooth, predictive motion.

Uses a Kalman filter to track camera position and velocity, providing:
- Smooth motion even with noisy measurements
- Position prediction during frames without detection
- Natural momentum and inertia
"""

import cv2
import numpy as np


class KalmanCamera:
    """
    Kalman filter for smooth, predictive camera motion.
    
    State vector: [x, y, vx, vy]
    - x, y: camera center position
    - vx, vy: camera velocity
    
    The filter predicts the next position based on velocity,
    then corrects when a measurement is available.
    """
    
    def __init__(self, initial_x, initial_y, process_noise=1e-4, measurement_noise=0.1):
        """
        Initialize Kalman filter for camera tracking.
        
        Args:
            initial_x, initial_y: Starting camera position
            process_noise: How much we expect the state to change unexpectedly
                          (lower = smoother, higher = more responsive)
            measurement_noise: How noisy we expect measurements to be
                              (lower = trust measurements more)
        """
        # 4 state variables (x, y, vx, vy), 2 measurements (x, y)
        self.kf = cv2.KalmanFilter(4, 2)
        
        # Transition matrix (constant velocity model)
        # [x']   [1 0 dt 0 ] [x ]
        # [y'] = [0 1 0  dt] [y ]
        # [vx']  [0 0 1  0 ] [vx]
        # [vy']  [0 0 0  1 ] [vy]
        self.kf.transitionMatrix = np.array([
            [1, 0, 1, 0],
            [0, 1, 0, 1],
            [0, 0, 1, 0],
            [0, 0, 0, 1]
        ], dtype=np.float32)
        
        # Measurement matrix (we observe x and y directly)
        self.kf.measurementMatrix = np.array([
            [1, 0, 0, 0],
            [0, 1, 0, 0]
        ], dtype=np.float32)
        
        # Process noise covariance (how much we trust the model)
        self.kf.processNoiseCov = np.eye(4, dtype=np.float32) * process_noise
        # Higher noise on velocity (less predictable)
        self.kf.processNoiseCov[2, 2] = process_noise * 10
        self.kf.processNoiseCov[3, 3] = process_noise * 10
        
        # Measurement noise covariance (how much we trust measurements)
        self.kf.measurementNoiseCov = np.eye(2, dtype=np.float32) * measurement_noise
        
        # Error covariance (initial uncertainty)
        self.kf.errorCovPost = np.eye(4, dtype=np.float32)
        
        # Initial state
        self.kf.statePost = np.array([
            [initial_x],
            [initial_y],
            [0],  # initial vx
            [0]   # initial vy
        ], dtype=np.float32)
        
        self.process_noise_base = process_noise
        self.measurement_noise_base = measurement_noise
        
    def predict(self):
        """
        Predict next frame position (call BEFORE measurement).
        
        Returns:
            tuple: (predicted_x, predicted_y)
        """
        prediction = self.kf.predict()
        return float(prediction[0, 0]), float(prediction[1, 0])
    
    def correct(self, measured_x, measured_y):
        """
        Correct state with a measurement (when MediaPipe detection is available).
        
        Args:
            measured_x, measured_y: Detected face center position
            
        Returns:
            tuple: (corrected_x, corrected_y)
        """
        measurement = np.array([
            [measured_x],
            [measured_y]
        ], dtype=np.float32)
        
        corrected = self.kf.correct(measurement)
        return float(corrected[0, 0]), float(corrected[1, 0])
    
    def get_position(self):
        """Return current smoothed position [x, y]."""
        state = self.kf.statePost
        return float(state[0, 0]), float(state[1, 0])
    
    def get_velocity(self):
        """Return current estimated velocity [vx, vy]."""
        state = self.kf.statePost
        return float(state[2, 0]), float(state[3, 0])
    
    def set_position(self, x, y):
        """Force set position (for initialization or jumps)."""
        self.kf.statePost[0, 0] = x
        self.kf.statePost[1, 0] = y
    
    def set_velocity(self, vx, vy):
        """Force set velocity."""
        self.kf.statePost[2, 0] = vx
        self.kf.statePost[3, 0] = vy
    
    def adjust_responsiveness(self, responsiveness=1.0):
        """
        Dynamically adjust filter responsiveness.
        
        Args:
            responsiveness: 0.5 = very smooth, 1.0 = default, 2.0 = very responsive
        """
        # Adjust measurement noise (lower = more responsive)
        self.kf.measurementNoiseCov = np.eye(2, dtype=np.float32) * (
            self.measurement_noise_base / responsiveness
        )


class KalmanCameraController:
    """
    High-level camera controller using Kalman filter with additional features.
    
    Features:
    - Look-ahead prediction
    - Adaptive zoom
    - Smooth speaker transitions
    - Dead zone support
    """
    
    def __init__(self, initial_x, initial_y, frame_width, 
                 process_noise=5e-5, measurement_noise=0.05):
        """
        Initialize camera controller.
        
        Args:
            initial_x, initial_y: Starting camera position
            frame_width: Width of source frame (for dead zone calculation)
            process_noise: Kalman process noise
            measurement_noise: Kalman measurement noise
        """
        self.kalman = KalmanCamera(initial_x, initial_y, process_noise, measurement_noise)
        self.frame_width = frame_width
        
        # Dead zone (ignore micro-movements)
        self.dead_zone = frame_width * 0.02  # 2% of frame width
        self.last_target = initial_x
        
        # Look-ahead prediction
        self.position_history = []
        self.history_max_size = 8
        
        # Speaker transition
        self.in_transition = False
        self.transition_start_time = 0
        self.transition_duration = 0.75  # seconds
        self.old_speaker_x = initial_x
        self.new_speaker_x = initial_x
        
        # Adaptive zoom
        self.base_crop_w = None
        self.reference_face_ratio = 0.15
        self.min_zoom = 0.9
        self.max_zoom = 1.15
        self.current_zoom = 1.0
        self.zoom_velocity = 0.0
    
    def update(self, target_x, target_y, dt, has_measurement=True):
        """
        Update camera position with optional measurement.
        
        Args:
            target_x, target_y: Target face position
            dt: Time delta since last frame
            has_measurement: Whether this is from actual detection (vs prediction)
            
        Returns:
            tuple: (camera_x, camera_y)
        """
        # Dead zone check
        if abs(target_x - self.last_target) < self.dead_zone:
            target_x = self.last_target
        else:
            self.last_target = target_x
        
        # Store for look-ahead
        self.position_history.append(target_x)
        if len(self.position_history) > self.history_max_size:
            self.position_history.pop(0)
        
        # Kalman update
        self.kalman.predict()
        
        if has_measurement:
            self.kalman.correct(target_x, target_y)
        
        return self.kalman.get_position()
    
    def get_lookahead_target(self, trend_weight=0.15):
        """
        Get predicted target position with trend bias.
        
        Args:
            trend_weight: How much to weight motion direction (0-1)
            
        Returns:
            float: Predicted x position
        """
        if len(self.position_history) < 2:
            return self.position_history[-1] if self.position_history else self.kalman.get_position()[0]
        
        mean_x = np.mean(self.position_history)
        
        # Compute trend (average velocity direction)
        velocities = np.diff(self.position_history)
        trend = np.mean(velocities) * trend_weight * len(self.position_history)
        
        return mean_x + trend
    
    def start_speaker_transition(self, old_x, new_x, current_time):
        """
        Start a smooth transition between speakers.
        
        Args:
            old_x: Previous speaker x position
            new_x: New speaker x position
            current_time: Current video time in seconds
        """
        self.in_transition = True
        self.transition_start_time = current_time
        self.old_speaker_x = old_x
        self.new_speaker_x = new_x
    
    def get_transition_target(self, current_time):
        """
        Get blended target position during speaker transition.
        
        Uses smooth ease-out curve for natural-feeling motion.
        
        Args:
            current_time: Current video time in seconds
            
        Returns:
            float: Blended x position (or new_x if not in transition)
        """
        if not self.in_transition:
            return self.new_speaker_x
        
        elapsed = current_time - self.transition_start_time
        
        if elapsed >= self.transition_duration:
            self.in_transition = False
            return self.new_speaker_x
        
        # Smooth ease-out curve: 1 - (1 - t)^3
        t = elapsed / self.transition_duration
        alpha = 1.0 - (1.0 - t) ** 3
        
        return (1 - alpha) * self.old_speaker_x + alpha * self.new_speaker_x
    
    def update_adaptive_zoom(self, face_width, crop_width, dt):
        """
        Calculate adaptive zoom factor based on face size.
        
        Args:
            face_width: Current detected face width in pixels
            crop_width: Current crop width
            dt: Time delta
            
        Returns:
            int: Adjusted crop width
        """
        if self.base_crop_w is None:
            self.base_crop_w = crop_width
        
        # Calculate current face ratio
        current_ratio = face_width / (crop_width + 1e-6)
        
        # Target zoom to achieve reference ratio
        target_zoom = current_ratio / self.reference_face_ratio
        target_zoom = np.clip(target_zoom, self.min_zoom, self.max_zoom)
        
        # Smooth zoom changes (critically damped spring)
        omega = 4.0  # Natural frequency
        error = target_zoom - self.current_zoom
        exp_term = np.exp(-omega * dt)
        
        self.current_zoom = target_zoom - (error + (error * omega + self.zoom_velocity) * dt) * exp_term
        self.zoom_velocity = (self.zoom_velocity - (error * omega * omega + self.zoom_velocity * omega) * dt) * exp_term
        
        # Clamp zoom
        self.current_zoom = np.clip(self.current_zoom, self.min_zoom, self.max_zoom)
        
        return int(self.base_crop_w * self.current_zoom)
    
    def reset_zoom(self):
        """Reset zoom to default."""
        self.current_zoom = 1.0
        self.zoom_velocity = 0.0


class SmoothValue:
    """
    Critically damped spring-based smoothing with dead zone support.
    (Kept for backwards compatibility and simpler use cases)
    """
    
    def __init__(self, initial_value, smoothing_time=1.0):
        self.value = initial_value
        self.velocity = 0
        self.smoothing_time = smoothing_time
        self.last_target = initial_value
    
    def update(self, target, dt=1/30, dead_zone=0):
        """
        Update with dead zone support.
        If target change is smaller than dead_zone, ignore the update.
        """
        # Dead zone check - ignore micro-movements
        if dead_zone > 0 and abs(target - self.last_target) < dead_zone:
            target = self.last_target
        else:
            self.last_target = target
        
        if self.smoothing_time <= 0:
            self.value = target
            return self.value
        
        omega = 2.0 / self.smoothing_time
        error = target - self.value
        exp_term = np.exp(-omega * dt)
        self.value = target - (error + (error * omega + self.velocity) * dt) * exp_term
        self.velocity = (self.velocity - (error * omega * omega + self.velocity * omega) * dt) * exp_term
        
        return self.value
