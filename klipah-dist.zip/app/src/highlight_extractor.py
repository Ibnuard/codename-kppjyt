import json
import logging
import requests
import os

from dotenv import load_dotenv

# Load env variables (looks for .env in CWD typically)
load_dotenv()

def load_api_key():
    """Load OpenRouter API Key from env."""
    try:
        # Check environment variable (loaded by dotenv)
        return os.environ.get("OPEN_ROUTER_API_KEY") 
    except Exception as e:
        logging.error(f"Error loading API Key: {e}")
    return None

def load_gemini_api_key():
    """Load Gemini API Key from env."""
    try:
        return os.environ.get("GEMINI_API_KEY") 
    except Exception as e:
        logging.error(f"Error loading Gemini API Key: {e}")
    return None

def extract_highlights(transcript_path, api_key=None, model="google/gemini-3-flash-preview"):
    """
    Send transcript to AI and ask for highlights under 60 seconds.
    Separated logic for Google Gemini (Direct) and OpenRouter.
    """
    # Determine which API to use
    is_gemini_direct = "gemini" in model.lower() and model.startswith("google/")
    
    # Strip prefix for direct Gemini calls to avoid 404
    api_model = model.replace("google/", "") if is_gemini_direct else model
    
    if is_gemini_direct:
        if not api_key:
            raise ValueError("Gemini API Key missing. Masukkan di Settings.")
    else:
        if not api_key:
            raise ValueError("OpenRouter API Key missing. Masukkan di Settings.")

    # Load transcript
    with open(transcript_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    # Extract text content depending on format
    full_text = ""
    if isinstance(data, dict):
        if 'content' in data: # Our normalized format
            segments = []
            for item in data['content']:
                segments.append(f"[{item['start']}-{item['end']}] {item['text']}")
            full_text = "\n".join(segments)
        elif 'text' in data: # Simple string
             full_text = data['text']
        elif 'segments' in data: # Whisper raw
             segments = []
             for item in data['segments']:
                segments.append(f"[{item.get('start')}-{item.get('end')}] {item.get('text')}")
             full_text = "\n".join(segments)

    if len(full_text) > 120000:
        logging.warning("Transcript is extremely long. Model might truncate.")

    prompt = (
        "You are an expert Indonesian video editor and viral content strategist. I will provide a transcript of an Indonesian video with timestamps [start-end]. "
        "Your task is to identify 5-10 of the most interesting, viral-worthy, or high-value moments suitable for short-form video (TikTok/Reels/Shorts). \n"
        "CRITICAL GUIDELINES:\n"
        "1. Duration: Each clip MUST be BETWEEN 20 AND 55 SECONDS. (Leave 5s headroom for intro). \n"
        "2. Merging Segments: If you find multiple consecutive interesting moments that are too short individually, MERGE them into a single highlight to satisfy the 20-55s requirement. (e.g. if 10-15s and 15-20s are interesting, combine them into 10-20s).\n"
        "3. Language & Culture: Focus on Indonesian language nuances, humor, emotional peaks, or important information relevant to an Indonesian audience.\n"
        "4. Quantity: Aim for 5-10 highlights. Scan the ENTIRE transcript to find the gold everywhere.\n"
        "5. Context: Ensure each clip starts and ends at a natural break in conversation.\n"
        "6. Title: Create a catchy, clickbait-style title in Indonesian for each clip.\n"
        "7. Output: Return ONLY a raw JSON list. No markdown, no explanations. \n"
        "Format: \n"
        "[{\"title\": \"Judul Viral\", \"start\": 10.5, \"end\": 45.2, \"reason\": \"Kenapa ini bakal viral\"}, ...]"
        "\n\nTRANSCRIPT:\n" + full_text
    )

    if is_gemini_direct:
        # --- GOOGLE GEMINI DIRECT ---
        logging.info(f"Sending request to Google Gemini API ({api_model})...")
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{api_model}:generateContent"
        headers = {"Content-Type": "application/json", "x-goog-api-key": api_key}
        payload = {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {"temperature": 0.7}
        }
    else:
        # --- OPENROUTER ---
        logging.info(f"Sending request to OpenRouter ({api_model})...")
        url = "https://openrouter.ai/api/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "http://localhost:8000", 
            "X-Title": "TranscriptClipper",
        }
        payload = {
            "model": api_model,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.7,
        }
    
    response = requests.post(url, headers=headers, json=payload)
    
    if response.status_code != 200:
        logging.error(f"API Error {response.status_code}: {response.text}")
        raise RuntimeError(f"API Error: {response.text}")

    result = response.json()
    
    if is_gemini_direct:
        try:
            content = result['candidates'][0]['content']['parts'][0]['text']
        except (KeyError, IndexError) as e:
            logging.error(f"Unexpected Gemini response structure: {result}")
            raise RuntimeError(f"Gemini API Error: {str(e)}")
    else:
        logging.info(f"Full API Response: {json.dumps(result, indent=2)}") # Log EVERYTHING
        message = result['choices'][0]['message']
        content = message.get('content', '')
        
        # Fallback for models (like Z.AI GLM) that might put output in 'reasoning'
        if not content and message.get('reasoning'):
            logging.warning("Content field empty. Using 'reasoning' field as fallback.")
            content = message['reasoning']
    
    logging.info(f"Raw Model Response: {content}") # Log raw response for debugging

    # DeepSeek R1 often includes <think> tags. We must remove them using regex or string manip.
    if "<think>" in content and "</think>" in content:
        content = content.split("</think>")[-1].strip()
    
    # Clean up markdown if model adds it
    clean_content = content.replace("```json", "").replace("```", "").strip()
    
    try:
        highlights = json.loads(clean_content)
        
        # Post-processing: Merge very close highlights or expand short ones
        # Sort by start time just in case
        highlights.sort(key=lambda x: float(x.get('start', 0)))
        
        processed_highlights = []
        i = 0
        while i < len(highlights):
            h = highlights[i]
            start = float(h.get('start', 0))
            end = float(h.get('end', 0))
            title = h.get('title', 'Highlight')
            reason = h.get('reason', '')
            
            duration = end - start
            
            # If too short, check if next one is close enough to merge
            if duration < 20 and i + 1 < len(highlights):
                next_h = highlights[i+1]
                next_start = float(next_h.get('start', 0))
                
                # If gap is less than 5 seconds, merge them
                if next_start - end < 5:
                    logging.info(f"Merging '{title}' and '{next_h.get('title')}' to increase duration.")
                    h['end'] = next_h.get('end')
                    h['title'] = f"{title} | {next_h.get('title')}"
                    h['reason'] = f"{reason} + {next_h.get('reason')}"
                    # Don't increment i yet, might need to merge multiple
                    highlights[i] = h
                    highlights.pop(i+1)
                    continue

            # If still too short after attempt to merge, expand it slightly to hit 20s minimum
            if (end - start) < 20:
                needed = 20 - (end - start)
                # Expand backwards and forwards equally if possible
                start = max(0, start - needed/2)
                end = end + needed/2
                h['start'] = start
                h['end'] = end
                logging.info(f"Expanding highlight '{title}' to {end-start:.1f}s to meet threshold.")

            processed_highlights.append(h)
            i += 1
        
        # Final filter for absolute minimum sanity (if it's still somehow < 15s, maybe ignore)
        final_highlights = [h for h in processed_highlights if (float(h.get('end', 0)) - float(h.get('start', 0))) >= 15]
        
        return final_highlights
    except json.JSONDecodeError as e:
        logging.error(f"Cleaned Content attempted to parse: {clean_content}")
        raise RuntimeError(f"Model returned invalid JSON. Check logs for raw output.")

def test_connection(api_key=None, model="google/gemini-3-flash-preview"):
    """Test API connection with a simple prompt."""
    is_gemini_direct = "gemini" in model.lower() and model.startswith("google/")
    api_model = model.replace("google/", "") if is_gemini_direct else model
    
    if is_gemini_direct:
        if not api_key:
            return {"success": False, "message": "Gemini API Key missing."}
        
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{api_model}:generateContent"
        headers = {"Content-Type": "application/json", "x-goog-api-key": api_key}
        payload = {"contents": [{"parts": [{"text": "Say 'OK' if you can hear me."}]}]}
    else:
        if not api_key:
            return {"success": False, "message": "API Key missing."}

        url = "https://openrouter.ai/api/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "http://localhost:8000", 
            "X-Title": "TranscriptClipperTest",
        }
        
        payload = {
            "model": api_model,
            "messages": [{"role": "user", "content": "Say 'OK' if you can hear me."}],
        }

    try:
        response = requests.post(url, headers=headers, json=payload, timeout=10)
        if response.status_code == 200:
            return {"success": True, "message": f"Connected! Model: {api_model} ({'Direct' if is_gemini_direct else 'OpenRouter'})", "data": response.json()}
        else:
            return {"success": False, "message": f"API Error {response.status_code}: {response.text}"}
    except Exception as e:
        return {"success": False, "message": f"Connection Failed: {str(e)}"}

def list_gemini_models(api_key=None):
    """List available Gemini models from Google API."""
    if not api_key:
        return []
    
    # The specific models the user wants to filter for
    ALLOWED_MODELS = [
        "google/gemini-2.5-flash",
        "google/gemini-flash-latest",
        "google/gemini-2.5-pro",
        "google/gemini-3-flash-preview",
        "google/gemini-3.1-flash-lite-preview"
    ]
    
    # Google API for listing models
    url = f"https://generativelanguage.googleapis.com/v1beta/models?key={api_key}"
    
    try:
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            data = response.json()
            # Filter for models that support generateContent and contain 'gemini'
            all_api_models = [
                m['name'].replace('models/', 'google/') 
                for m in data.get('models', []) 
                if 'generateContent' in m.get('supportedGenerationMethods', [])
                and 'gemini' in m['name'].lower()
            ]
            
            # Intersection with our allowed list to ensure only requested ones are returned
            # and only if they actually exist in the API catalog
            filtered_models = [m for m in ALLOWED_MODELS if m in all_api_models]
            
            # If for some reason the filtered list is empty (e.g. API returns different names), 
            # fall back to returning the full list filtered by 'gemini' but don't just give up
            if not filtered_models:
                logging.info("Targeted models not found in API list, returning all Gemini models.")
                return sorted(all_api_models, reverse=True)
                
            return filtered_models
        else:
            logging.error(f"API Error listing models {response.status_code}: {response.text}")
            return []
    except Exception as e:
        logging.error(f"Error listing Gemini models: {e}")
        return []
