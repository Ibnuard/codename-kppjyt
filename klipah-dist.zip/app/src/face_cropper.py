import os
import cv2
import logging
import numpy as np
import mediapipe as mp
from collections import deque

# MediaPipe Face Detector
mp_image = mp.Image
BaseOptions = mp.tasks.BaseOptions
FaceDetectorOptions = mp.tasks.vision.FaceDetectorOptions
FaceDetector = mp.tasks.vision.FaceDetector

# Path to the TFLite model
BASE_DIR = os.path.dirname(os.path.dirname(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "blaze_face_short_range.tflite")

# =====================================================
# ANTI-JITTER CONFIGURATION
# =====================================================

# Detection frequency - process every N frames (reduces MediaPipe load)
DETECTION_INTERVAL = 3

# Speaker switching thresholds
MIN_SWITCH_DELAY_SECONDS = 2.0      # Wait minimum 2 seconds before considering switch
LOCK_AFTER_SWITCH_SECONDS = 3.0    # Lock speaker for 3 seconds after switching
ACTIVITY_SWITCH_RATIO = 1.8        # Require 80% higher activity to trigger switch

# Smoothing parameters
DEFAULT_SMOOTH_TIME = 1.0          # 1 second camera settling time (was 0.4)
DEAD_ZONE_PERCENT = 0.02           # Ignore movements < 2% of frame width

# Detection confidence
MIN_DETECTION_CONFIDENCE = 0.6     # Higher threshold (was 0.4)

# Error handling
MAX_DETECTION_RETRIES = 2

# =====================================================
# OUTPUT RESOLUTION (HD for YouTube/Facebook)
# =====================================================
# Target 9:16 vertical output dimensions
# 1080x1920 = Full HD vertical (recommended)
# 720x1280 = HD vertical (minimum for HD on platforms)
OUTPUT_WIDTH = 1080   # Target output width
OUTPUT_HEIGHT = 1920  # Target output height (9:16 aspect ratio)

# =====================================================

# Create detector with higher confidence threshold
detector = None

def get_detector():
    """Lazy initialization of detector with error handling."""
    global detector
    if detector is None:
        try:
            detector = FaceDetector.create_from_options(
                FaceDetectorOptions(
                    base_options=BaseOptions(model_asset_path=MODEL_PATH),
                    running_mode=mp.tasks.vision.RunningMode.IMAGE,
                    min_detection_confidence=MIN_DETECTION_CONFIDENCE
                )
            )
        except Exception as e:
            logging.error(f"Failed to initialize MediaPipe detector: {e}")
            raise
    return detector


class SmoothValue:
    """Critically damped spring-based smoothing with dead zone support."""
    def __init__(self, initial_value, smoothing_time=DEFAULT_SMOOTH_TIME):
        self.value = initial_value
        self.velocity = 0
        self.smoothing_time = smoothing_time
        self.last_target = initial_value
    
    def update(self, target, dt=1/30, dead_zone=0):
        """
        Update with dead zone support.
        If target change is smaller than dead_zone, ignore the update.
        """
        # Dead zone check - ignore micro-movements
        if dead_zone > 0 and abs(target - self.last_target) < dead_zone:
            target = self.last_target
        else:
            self.last_target = target
        
        if self.smoothing_time <= 0:
            self.value = target
            return self.value
        
        omega = 2.0 / self.smoothing_time
        error = target - self.value
        exp_term = np.exp(-omega * dt)
        self.value = target - (error + (error * omega + self.velocity) * dt) * exp_term
        self.velocity = (self.velocity - (error * omega * omega + self.velocity * omega) * dt) * exp_term
        
        return self.value


class FaceState:
    def __init__(self, id, bbox):
        self.id = id
        self.bbox = bbox
        self.center_x = bbox.origin_x + bbox.width / 2
        self.center_y = bbox.origin_y + bbox.height / 2
        self.size = bbox.width * bbox.height
        
        # Track raw mouth positions for delta calculation
        self.prev_mouth_y = None
        self.mouth_deltas = deque(maxlen=30)  # Increased buffer for smoother averaging
        self.activity_score = 0
        
        self.frames_since_seen = 0
        
        # Interpolation support
        self.prev_center_x = self.center_x
        self.prev_center_y = self.center_y

    def update_bbox(self, bbox):
        # Store previous position for interpolation
        self.prev_center_x = self.center_x
        self.prev_center_y = self.center_y
        
        self.bbox = bbox
        self.center_x = bbox.origin_x + bbox.width / 2
        self.center_y = bbox.origin_y + bbox.height / 2
        self.size = bbox.width * bbox.height

    def get_interpolated_center(self, t):
        """Get interpolated center position. t=0 is previous, t=1 is current."""
        x = self.prev_center_x + (self.center_x - self.prev_center_x) * t
        y = self.prev_center_y + (self.center_y - self.prev_center_y) * t
        return x, y

    def update_activity(self, nose, mouth):
        """Calculate speaking activity based on mouth MOVEMENT (delta)."""
        # Use absolute mouth position normalized to bbox
        mouth_y = (mouth.y - self.bbox.origin_y) / (self.bbox.height + 1e-6)
        
        if self.prev_mouth_y is not None:
            # Movement delta
            delta = abs(mouth_y - self.prev_mouth_y) * 1000  # Scale up
            self.mouth_deltas.append(delta)
        
        self.prev_mouth_y = mouth_y
        
        if len(self.mouth_deltas) >= 5:
            # Activity = mean of recent deltas with slower EMA
            raw = np.mean(list(self.mouth_deltas)[-15:])
            # Slower EMA for more stable activity score (was 0.5/0.5)
            self.activity_score = 0.3 * raw + 0.7 * self.activity_score
        
    def match_score(self, det_center_x, det_center_y, det_size):
        dx = abs(self.center_x - det_center_x)
        dy = abs(self.center_y - det_center_y) * 0.5
        size_ratio = max(self.size, det_size) / (min(self.size, det_size) + 1e-6)
        size_penalty = (size_ratio - 1) * 30
        return dx + dy + size_penalty


def safe_detect(detector, mp_img, frame_count, max_retries=MAX_DETECTION_RETRIES):
    """
    Safely run MediaPipe detection with retry logic.
    Returns None on failure instead of crashing.
    """
    for attempt in range(max_retries + 1):
        try:
            result = detector.detect(mp_img)
            return result
        except Exception as e:
            if attempt < max_retries:
                logging.warning(f"MediaPipe detection retry {attempt + 1}/{max_retries} on frame {frame_count}: {e}")
                continue
            else:
                logging.warning(f"MediaPipe detection failed after {max_retries} retries on frame {frame_count}: {e}")
                return None
    return None


def dynamic_face_crop_9x16(input_video, output_video, smooth_factor=DEFAULT_SMOOTH_TIME, transcript_hints=None):
    """
    Dynamic face cropping with robust error handling and anti-jitter improvements.
    
    Args:
        input_video: Path to input video
        output_video: Path to output video
        smooth_factor: Camera smoothing time in seconds (default: 1.0)
        transcript_hints: Optional list of dicts with speaker timing hints
                         Format: [{"start": 0.0, "end": 5.0, "speaker_position": "left|right|center"}, ...]
    """
    cap = cv2.VideoCapture(input_video)
    
    # Get detector with lazy initialization
    try:
        face_detector = get_detector()
    except Exception as e:
        logging.error(f"Cannot initialize face detector: {e}")
        raise

    try:
        w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        
        source_fps = cap.get(cv2.CAP_PROP_FPS)
        if source_fps <= 0:
            source_fps = 30.0
        
        dt = 1.0 / source_fps
        logging.info(f"Face crop source: {w}x{h} @ {source_fps:.1f}fps")

        if w == 0 or h == 0:
            raise RuntimeError("Invalid video dimensions (0x0)")

        # =====================================================
        # CALCULATE CROP REGION (from source)
        # =====================================================
        # We need to crop a 9:16 region from the source, then scale up to target resolution
        
        # Calculate the crop dimensions from source (9:16 aspect ratio)
        # Use full height of source minus small top margin
        top_margin = int(h * 0.05)  # Reduced margin for more content
        crop_h = h - top_margin
        crop_w = int(crop_h * 9 / 16)
        
        # If crop width exceeds source width, recalculate based on width
        if crop_w > w:
            crop_w = w
            crop_h = int(crop_w * 16 / 9)
            top_margin = (h - crop_h) // 2
        
        # Ensure even dimensions for crop
        if crop_w % 2 != 0: crop_w -= 1
        if crop_h % 2 != 0: crop_h -= 1
        
        logging.info(f"Crop region: {crop_w}x{crop_h} from source {w}x{h}")
        
        # =====================================================
        # OUTPUT DIMENSIONS (HD for platforms)
        # =====================================================
        # Final output is scaled to target resolution
        output_w = OUTPUT_WIDTH
        output_h = OUTPUT_HEIGHT
        
        # Ensure even dimensions
        if output_w % 2 != 0: output_w -= 1
        if output_h % 2 != 0: output_h -= 1
        
        logging.info(f"Output resolution: {output_w}x{output_h} (HD vertical)")

        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        out = cv2.VideoWriter(output_video, fourcc, source_fps, (output_w, output_h))

        if not out.isOpened():
            raise RuntimeError("Failed to open VideoWriter")

        # Use increased smoothing time
        camera_x = SmoothValue(w / 2, smoothing_time=smooth_factor)
        
        # Dead zone in pixels (2% of frame width)
        dead_zone_pixels = w * DEAD_ZONE_PERCENT
        
        tracked_faces = {}
        next_id = 0
        
        # Speaker state with improved switching logic
        current_speaker_id = None
        last_switch_time = -LOCK_AFTER_SWITCH_SECONDS  # Allow immediate first selection
        MIN_FRAMES_BEFORE_SWITCH = int(source_fps * MIN_SWITCH_DELAY_SECONDS)
        frames_on_current = 0
        
        last_valid_target = w / 2
        frames_without_face = 0
        
        # Cache for skip-frame detection
        last_detection_result = None
        detection_frame_offset = 0

        frame_count = 0
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        
        while True:
            try:
                ret, frame = cap.read()
                if not ret:
                    break
                
                # Validation check for frame
                if frame is None or frame.size == 0:
                    logging.warning(f"Empty frame encountered at index {frame_count}")
                    continue
                
                frame_count += 1
                current_time = frame_count / source_fps
                
                # =====================================================
                # SKIP-FRAME DETECTION - Only detect every N frames
                # =====================================================
                run_detection = (frame_count % DETECTION_INTERVAL == 0)
                detection_frame_offset += 1
                
                if run_detection:
                    detection_frame_offset = 0
                    
                    # Validate frame before MediaPipe processing
                    if frame.shape[0] < 10 or frame.shape[1] < 10:
                        logging.warning(f"Frame too small at {frame_count}")
                        result = None
                    else:
                        try:
                            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                            mp_img = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
                            result = safe_detect(face_detector, mp_img, frame_count)
                        except Exception as mp_err:
                            logging.warning(f"MediaPipe processing failed on frame {frame_count}: {mp_err}")
                            result = None
                    
                    last_detection_result = result
                else:
                    # Use cached result for non-detection frames
                    result = last_detection_result

                detected_this_frame = set()
                
                if result and result.detections:
                    frames_without_face = 0
                    
                    for det in result.detections:
                        bbox = det.bounding_box
                        kps = det.keypoints
                        
                        # Safety check for keypoints
                        if len(kps) < 4:
                            continue
                            
                        nose = kps[2]
                        mouth = kps[3]
                        
                        det_cx = bbox.origin_x + bbox.width / 2
                        det_cy = bbox.origin_y + bbox.height / 2
                        det_size = bbox.width * bbox.height
                        
                        best_match_id = None
                        best_score = 80
                        
                        for fid, face in tracked_faces.items():
                            if fid in detected_this_frame:
                                continue
                            score = face.match_score(det_cx, det_cy, det_size)
                            if score < best_score:
                                best_score = score
                                best_match_id = fid
                        
                        if best_match_id is not None:
                            tracked_faces[best_match_id].update_bbox(bbox)
                            tracked_faces[best_match_id].update_activity(nose, mouth)
                            tracked_faces[best_match_id].frames_since_seen = 0
                            detected_this_frame.add(best_match_id)
                        else:
                            new_face = FaceState(next_id, bbox)
                            new_face.update_activity(nose, mouth)
                            tracked_faces[next_id] = new_face
                            detected_this_frame.add(next_id)
                            next_id += 1
                else:
                    frames_without_face += 1

                # Age out old faces (increased timeout for stability)
                for fid in list(tracked_faces.keys()):
                    if fid not in detected_this_frame:
                        tracked_faces[fid].frames_since_seen += 1
                        # Only remove after 2 seconds of not seeing (was 1.5)
                        if tracked_faces[fid].frames_since_seen > int(source_fps * 2.0):
                            del tracked_faces[fid]

                # =====================================================
                # SPEAKER SELECTION WITH HYSTERESIS
                # =====================================================
                target_x = last_valid_target
                active_faces = [f for f in tracked_faces.values() if f.frames_since_seen == 0]
                
                if active_faces:
                    # Sort by activity (highest first)
                    active_faces.sort(key=lambda f: f.activity_score, reverse=True)
                    most_active = active_faces[0]
                    
                    if frame_count % 60 == 0 and len(active_faces) > 1:
                        activity_str = ", ".join([f"F{f.id}:{f.activity_score:.2f}" for f in active_faces[:3]])
                        logging.debug(f"Frame {frame_count}: Activities [{activity_str}] Current: {current_speaker_id}")
                    
                    current_speaker = tracked_faces.get(current_speaker_id) if current_speaker_id else None
                    if current_speaker and current_speaker.frames_since_seen > 0:
                        current_speaker = None
                        current_speaker_id = None
                    
                    if current_speaker is None:
                        # First speaker selection
                        current_speaker_id = most_active.id
                        current_speaker = most_active
                        frames_on_current = 0
                        last_switch_time = current_time
                    else:
                        frames_on_current += 1
                        
                        # =====================================================
                        # HYSTERESIS SWITCHING LOGIC
                        # =====================================================
                        time_since_switch = current_time - last_switch_time
                        
                        # Only consider switching if:
                        # 1. Not in lock period
                        # 2. Waited minimum time on current speaker
                        # 3. Different face is more active
                        can_switch = (
                            time_since_switch > LOCK_AFTER_SWITCH_SECONDS and
                            frames_on_current >= MIN_FRAMES_BEFORE_SWITCH and
                            most_active.id != current_speaker_id
                        )
                        
                        if can_switch:
                            curr_act = current_speaker.activity_score
                            other_act = most_active.activity_score
                            
                            should_switch = False
                            
                            # More conservative switching logic
                            if curr_act < 0.05:  
                                # Current speaker is basically silent
                                should_switch = other_act > 0.15
                            else:
                                # Require significantly higher activity (80% more)
                                should_switch = other_act > curr_act * ACTIVITY_SWITCH_RATIO
                            
                            if should_switch:
                                logging.info(f"Switch: {current_speaker_id} -> {most_active.id} (act: {curr_act:.2f} -> {other_act:.2f})")
                                current_speaker_id = most_active.id
                                current_speaker = most_active
                                frames_on_current = 0
                                last_switch_time = current_time
                    
                    # Get target position (with interpolation for skip-frame smoothness)
                    if current_speaker:
                        if DETECTION_INTERVAL > 1 and detection_frame_offset > 0:
                            # Interpolate between detection frames
                            t = detection_frame_offset / DETECTION_INTERVAL
                            interp_x, _ = current_speaker.get_interpolated_center(min(t, 1.0))
                            target_x = interp_x
                        else:
                            target_x = current_speaker.center_x
                        last_valid_target = target_x
                else:
                    # No faces detected
                    if frames_without_face < int(source_fps * 1.0):
                        # Keep last position for 1 second
                        target_x = last_valid_target
                    else:
                        # Slowly drift to center
                        target_x = last_valid_target * 0.998 + (w / 2) * 0.002

                # =====================================================
                # SMOOTH CAMERA UPDATE WITH DEAD ZONE
                # =====================================================
                center_x = int(camera_x.update(target_x, dt, dead_zone=dead_zone_pixels))

                # Safe Crop Calculation using crop dimensions
                x1 = center_x - crop_w // 2
                x2 = x1 + crop_w

                if x1 < 0:
                    x1 = 0
                    x2 = crop_w
                if x2 > w:
                    x2 = w
                    x1 = w - crop_w

                # Final boundary check (CRITICAL for OpenCV safety)
                x1 = max(0, min(x1, w - 1))
                x2 = max(x1 + 1, min(x2, w))
                y1 = max(0, min(top_margin, h - 1))
                y2 = min(top_margin + crop_h, h)
                
                # Check resulting dimensions
                actual_crop_w = x2 - x1
                actual_crop_h = y2 - y1
                
                if actual_crop_w < 10 or actual_crop_h < 10:
                    logging.warning(f"Crop too small: {actual_crop_w}x{actual_crop_h}, skipping frame")
                    continue

                cropped = frame[y1:y2, x1:x2]
                
                # Scale to HD output resolution (1080x1920)
                try:
                    scaled = cv2.resize(cropped, (output_w, output_h), interpolation=cv2.INTER_LANCZOS4)
                except Exception as resize_err:
                    logging.error(f"Resize failed: {resize_err}")
                    continue
                
                try:
                    out.write(scaled)
                except Exception as write_err:
                    logging.error(f"Write failed at frame {frame_count}: {write_err}")
            
            except Exception as frame_err:
                logging.error(f"Error processing frame {frame_count}: {frame_err}")
                continue

    except Exception as e:
        logging.error(f"Fatal error in face cropper: {e}")
        raise
    
    finally:
        if 'cap' in locals() and cap.isOpened():
            cap.release()
        if 'out' in locals() and out.isOpened():
            out.release()
        logging.info(f"Face crop finished. Processed {frame_count} frames.")


# =====================================================
# V2: CINEMATIC FACE TRACKING SYSTEM
# =====================================================
# New tracking-first architecture with:
# - Optical flow for continuous tracking
# - Kalman filter for smooth, predictive motion
# - Adaptive zoom based on face size
# - Look-ahead prediction for anticipatory camera
# - Smooth speaker transitions
# - Hybrid fallback strategy
# =====================================================

from .FaceOpticalTracker import FaceOpticalTracker, MultiPersonOpticalTracker
from .KalmanCamera import KalmanCamera, KalmanCameraController

# V2 Configuration
MEDIAPIPE_INTERVAL_V2 = 12         # Run MediaPipe every N frames (~2.5x/sec at 30fps)
OPTICAL_FLOW_MIN_CONFIDENCE = 0.3  # Minimum optical flow confidence

# Look-ahead settings
LOOKAHEAD_WINDOW = 8               # Frames of history
LOOKAHEAD_TREND_WEIGHT = 0.05      # Lower weight to reduce jitter from prediction

# Adaptive zoom settings  
ADAPTIVE_ZOOM_ENABLED = True
REFERENCE_FACE_RATIO = 0.15        # Target face size as ratio of crop
MIN_ZOOM = 0.9
MAX_ZOOM = 1.15

# Speaker transition
SPEAKER_TRANSITION_DURATION = 0.4  # Seconds for cross-fade (Faster response)


class LookAheadPredictor:
    """Store recent positions and predict next target with trend bias."""
    
    def __init__(self, window_size=LOOKAHEAD_WINDOW):
        self.positions = deque(maxlen=window_size)
    
    def add_position(self, x):
        self.positions.append(x)
    
    def predict(self, trend_weight=LOOKAHEAD_TREND_WEIGHT):
        """
        Compute predicted position with trend bias.
        predicted_x = mean(positions) + trend_bias
        """
        if len(self.positions) < 2:
            return self.positions[-1] if self.positions else None
        
        positions_list = list(self.positions)
        mean_x = np.mean(positions_list)
        
        # Trend = average velocity direction
        velocities = np.diff(positions_list)
        trend = np.mean(velocities) * trend_weight * len(positions_list)
        
        return mean_x + trend
    
    def clear(self):
        self.positions.clear()


class AdaptiveZoom:
    """Dynamically adjust crop width based on face size."""
    
    def __init__(self, base_crop_w, reference_face_ratio=REFERENCE_FACE_RATIO):
        self.base_crop_w = base_crop_w
        self.reference_ratio = reference_face_ratio
        self.min_zoom = MIN_ZOOM
        self.max_zoom = MAX_ZOOM
        self.current_zoom = 1.0
        self.zoom_velocity = 0.0
    
    def update(self, face_width, crop_width, dt):
        """
        Calculate zoom factor and return adjusted crop width.
        zoom = clamp(reference / current_ratio, min, max)
        """
        current_ratio = face_width / (crop_width + 1e-6)
        
        # If face is smaller than reference, zoom in (smaller crop)
        # If face is larger than reference, zoom out (larger crop)
        target_zoom = current_ratio / self.reference_ratio
        target_zoom = np.clip(target_zoom, self.min_zoom, self.max_zoom)
        
        # Smooth zoom changes (critically damped spring)
        omega = 3.0  # Natural frequency for zoom
        error = target_zoom - self.current_zoom
        exp_term = np.exp(-omega * dt)
        
        self.current_zoom = target_zoom - (error + (error * omega + self.zoom_velocity) * dt) * exp_term
        self.zoom_velocity = (self.zoom_velocity - (error * omega * omega + self.zoom_velocity * omega) * dt) * exp_term
        
        # Clamp zoom
        self.current_zoom = np.clip(self.current_zoom, self.min_zoom, self.max_zoom)
        
        return int(self.base_crop_w * self.current_zoom)
    
    def reset(self):
        self.current_zoom = 1.0
        self.zoom_velocity = 0.0


class SpeakerTransition:
    """Cross-fade camera position during speaker switches."""
    
    def __init__(self, transition_duration=SPEAKER_TRANSITION_DURATION):
        self.transition_duration = transition_duration
        self.old_target = None
        self.new_target = None
        self.transition_start = None
        self.in_transition = False
    
    def start_transition(self, old_x, new_x, current_time):
        self.old_target = old_x
        self.new_target = new_x
        self.transition_start = current_time
        self.in_transition = True
    
    def get_target(self, current_time):
        """
        Blend: target = alpha * old + (1-alpha) * new
        where alpha decreases from 1 to 0 using ease-out curve
        """
        if not self.in_transition:
            return self.new_target if self.new_target is not None else self.old_target
        
        elapsed = current_time - self.transition_start
        if elapsed >= self.transition_duration:
            self.in_transition = False
            return self.new_target
        
        # Smooth ease-out curve: 1 - (1-t)^3
        t = elapsed / self.transition_duration
        alpha = (1.0 - t) ** 3
        
        return alpha * self.old_target + (1 - alpha) * self.new_target


def dynamic_face_crop_9x16_v2(input_video, output_video, smooth_factor=1.0, transcript_hints=None):
    """
    Tracking-first face cropping with cinematic camera behavior.
    
    NEW ARCHITECTURE (V2):
    Frame → Optical Flow TRACK face → 
             occasional MediaPipe correction → 
             Kalman + smoothing → adaptive crop
    
    Features:
    - Optical flow tracking runs every frame
    - MediaPipe runs every 12 frames as correction layer
    - Kalman filter for smooth, predictive motion
    - Look-ahead prediction for anticipatory camera
    - Adaptive zoom based on face size
    - Smooth cross-fade transitions between speakers
    - Hybrid fallback (optical flow → drift to center)
    
    Args:
        input_video: Path to input video
        output_video: Path to output video
        smooth_factor: Camera smoothing factor (default: 1.0)
        transcript_hints: Optional speaker timing hints
    """
    cap = cv2.VideoCapture(input_video)
    
    # Get detector
    try:
        face_detector = get_detector()
    except Exception as e:
        logging.error(f"Cannot initialize face detector: {e}")
        raise

    try:
        w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        
        source_fps = cap.get(cv2.CAP_PROP_FPS)
        if source_fps <= 0:
            source_fps = 30.0
        
        dt = 1.0 / source_fps
        logging.info(f"[V2] Face crop source: {w}x{h} @ {source_fps:.1f}fps")

        if w == 0 or h == 0:
            raise RuntimeError("Invalid video dimensions (0x0)")

        # Calculate crop region (9:16 aspect ratio)
        top_margin = int(h * 0.05)
        crop_h = h - top_margin
        crop_w = int(crop_h * 9 / 16)
        
        if crop_w > w:
            crop_w = w
            crop_h = int(crop_w * 16 / 9)
            top_margin = (h - crop_h) // 2
        
        if crop_w % 2 != 0: crop_w -= 1
        if crop_h % 2 != 0: crop_h -= 1
        
        base_crop_w = crop_w  # Store for adaptive zoom
        
        logging.info(f"[V2] Crop region: {crop_w}x{crop_h}")

        # Output dimensions
        output_w = OUTPUT_WIDTH
        output_h = OUTPUT_HEIGHT
        if output_w % 2 != 0: output_w -= 1
        if output_h % 2 != 0: output_h -= 1
        
        logging.info(f"[V2] Output resolution: {output_w}x{output_h}")

        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        out = cv2.VideoWriter(output_video, fourcc, source_fps, (output_w, output_h))

        if not out.isOpened():
            raise RuntimeError("Failed to open VideoWriter")

        # =====================================================
        # V2 TRACKING COMPONENTS
        # =====================================================
        
        # Kalman camera controller
        # Kalman camera controller - Tuned for SMOOTHNESS
        # Low process_noise = high inertia (smooths out jitter)
        # Higher measurement_noise = trust predicted path more than noisy detections
        kalman_camera = KalmanCamera(w / 2, h / 2, process_noise=1e-5, measurement_noise=0.1)
        
        # Multi-person optical flow tracker
        optical_trackers = MultiPersonOpticalTracker(max_faces=5)
        
        # Look-ahead predictor
        lookahead = LookAheadPredictor(window_size=LOOKAHEAD_WINDOW)
        
        # Adaptive zoom
        adaptive_zoom = AdaptiveZoom(base_crop_w, REFERENCE_FACE_RATIO) if ADAPTIVE_ZOOM_ENABLED else None
        
        # Speaker transition handler
        speaker_transition = SpeakerTransition(SPEAKER_TRANSITION_DURATION)
        
        # Dead zone
        dead_zone_pixels = w * DEAD_ZONE_PERCENT
        
        # Tracking state
        tracked_faces = {}
        next_id = 0
        current_speaker_id = None
        last_switch_time = -LOCK_AFTER_SWITCH_SECONDS
        MIN_FRAMES_BEFORE_SWITCH = int(source_fps * MIN_SWITCH_DELAY_SECONDS)
        frames_on_current = 0
        
        last_valid_target = w / 2
        last_valid_face_width = crop_w * 0.15  # Default face width
        frames_without_face = 0
        last_target_x = w / 2

        # Previous grayscale frame for optical flow
        prev_gray = None

        frame_count = 0
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        
        while True:
            try:
                ret, frame = cap.read()
                if not ret:
                    break
                
                if frame is None or frame.size == 0:
                    logging.warning(f"[V2] Empty frame at {frame_count}")
                    continue
                
                frame_count += 1
                current_time = frame_count / source_fps
                
                # Convert to grayscale for optical flow
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                
                # =====================================================
                # OPTICAL FLOW TRACKING (every frame)
                # =====================================================
                if prev_gray is not None:
                    optical_results = optical_trackers.update_all(gray)
                
                # =====================================================
                # MEDIAPIPE DETECTION (every N frames)
                # =====================================================
                run_detection = (frame_count % MEDIAPIPE_INTERVAL_V2 == 0) or frame_count == 1
                
                detected_this_frame = set()
                has_mediapipe_measurement = False
                
                if run_detection:
                    if frame.shape[0] >= 10 and frame.shape[1] >= 10:
                        try:
                            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                            mp_img = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
                            result = safe_detect(face_detector, mp_img, frame_count)
                            
                            if result and result.detections:
                                has_mediapipe_measurement = True
                                frames_without_face = 0
                                
                                for det in result.detections:
                                    bbox = det.bounding_box
                                    kps = det.keypoints
                                    
                                    if len(kps) < 4:
                                        continue
                                    
                                    nose, mouth = kps[2], kps[3]
                                    det_cx = bbox.origin_x + bbox.width / 2
                                    det_cy = bbox.origin_y + bbox.height / 2
                                    det_size = bbox.width * bbox.height
                                    
                                    # Match to existing face
                                    best_match_id = None
                                    best_score = 80
                                    
                                    for fid, face in tracked_faces.items():
                                        if fid in detected_this_frame:
                                            continue
                                        score = face.match_score(det_cx, det_cy, det_size)
                                        if score < best_score:
                                            best_score = score
                                            best_match_id = fid
                                    
                                    if best_match_id is not None:
                                        tracked_faces[best_match_id].update_bbox(bbox)
                                        tracked_faces[best_match_id].update_activity(nose, mouth)
                                        tracked_faces[best_match_id].frames_since_seen = 0
                                        detected_this_frame.add(best_match_id)
                                        
                                        # Reinitialize optical flow tracker
                                        tracker = optical_trackers.get_or_create_tracker(best_match_id)
                                        tracker.reinitialize_if_needed(
                                            gray, bbox.origin_x, bbox.origin_y, 
                                            bbox.width, bbox.height, force=False
                                        )
                                    else:
                                        # New face
                                        new_face = FaceState(next_id, bbox)
                                        new_face.update_activity(nose, mouth)
                                        tracked_faces[next_id] = new_face
                                        detected_this_frame.add(next_id)
                                        
                                        # Initialize optical flow tracker
                                        tracker = optical_trackers.get_or_create_tracker(next_id)
                                        tracker.initialize_from_bbox(
                                            gray, bbox.origin_x, bbox.origin_y,
                                            bbox.width, bbox.height
                                        )
                                        
                                        next_id += 1
                            else:
                                frames_without_face += 1
                                
                        except Exception as mp_err:
                            logging.warning(f"[V2] MediaPipe error frame {frame_count}: {mp_err}")
                    else:
                        frames_without_face += 1

                # Age out old faces
                for fid in list(tracked_faces.keys()):
                    if fid not in detected_this_frame:
                        tracked_faces[fid].frames_since_seen += 1
                        if tracked_faces[fid].frames_since_seen > int(source_fps * 2.0):
                            del tracked_faces[fid]
                            optical_trackers.remove_tracker(fid)

                # =====================================================
                # SPEAKER SELECTION WITH HYSTERESIS
                # =====================================================
                target_x = last_valid_target
                current_face_width = last_valid_face_width
                active_faces = [f for f in tracked_faces.values() if f.frames_since_seen == 0]
                
                if active_faces:
                    active_faces.sort(key=lambda f: f.activity_score, reverse=True)
                    most_active = active_faces[0]
                    
                    current_speaker = tracked_faces.get(current_speaker_id) if current_speaker_id else None
                    if current_speaker and current_speaker.frames_since_seen > 0:
                        current_speaker = None
                        current_speaker_id = None
                    
                    old_speaker_x = last_valid_target
                    
                    if current_speaker is None:
                        # First speaker selection
                        current_speaker_id = most_active.id
                        current_speaker = most_active
                        frames_on_current = 0
                        last_switch_time = current_time
                    else:
                        frames_on_current += 1
                        old_speaker_x = current_speaker.center_x
                        
                        # Hysteresis switching
                        time_since_switch = current_time - last_switch_time
                        
                        can_switch = (
                            time_since_switch > LOCK_AFTER_SWITCH_SECONDS and
                            frames_on_current >= MIN_FRAMES_BEFORE_SWITCH and
                            most_active.id != current_speaker_id
                        )
                        
                        if can_switch:
                            curr_act = current_speaker.activity_score
                            other_act = most_active.activity_score
                            
                            should_switch = False
                            if curr_act < 0.05:
                                should_switch = other_act > 0.15
                            else:
                                should_switch = other_act > curr_act * ACTIVITY_SWITCH_RATIO
                            
                            if should_switch:
                                logging.info(f"[V2] Switch: {current_speaker_id} -> {most_active.id}")
                                
                                # Start smooth speaker transition
                                speaker_transition.start_transition(
                                    old_speaker_x, most_active.center_x, current_time
                                )
                                
                                current_speaker_id = most_active.id
                                current_speaker = most_active
                                frames_on_current = 0
                                last_switch_time = current_time
                    
                    # Get target position
                    if current_speaker:
                        # Use optical flow estimate if available
                        tracker = optical_trackers.get_tracker(current_speaker_id)
                        
                        if tracker and tracker.is_tracking_valid():
                            # Blend optical flow and detection
                            of_x, of_y = tracker.get_center_estimate()
                            if has_mediapipe_measurement:
                                # Trust detection more when available
                                target_x = 0.7 * current_speaker.center_x + 0.3 * of_x
                            else:
                                # Trust optical flow between detections
                                target_x = 0.3 * current_speaker.center_x + 0.7 * of_x
                        else:
                            target_x = current_speaker.center_x
                        
                        current_face_width = current_speaker.bbox.width
                        last_valid_face_width = current_face_width
                        
                        # Apply speaker transition if active
                        if speaker_transition.in_transition:
                            speaker_transition.new_target = target_x
                            target_x = speaker_transition.get_target(current_time)
                        
                        last_valid_target = target_x
                        
                else:
                    # =====================================================
                    # HYBRID FALLBACK STRATEGY
                    # =====================================================
                    # Try optical flow first
                    if current_speaker_id and optical_trackers.get_tracker(current_speaker_id):
                        tracker = optical_trackers.get_tracker(current_speaker_id)
                        if tracker.is_tracking_valid():
                            of_x, _ = tracker.get_center_estimate()
                            target_x = of_x
                            last_valid_target = target_x
                        else:
                            # Optical flow failed - slowly drift to center
                            if frames_without_face < int(source_fps * 1.0):
                                target_x = last_valid_target
                            else:
                                # Slow drift to center
                                target_x = last_valid_target * 0.995 + (w / 2) * 0.005
                    else:
                        # No tracker - drift to center
                        if frames_without_face < int(source_fps * 1.0):
                            target_x = last_valid_target
                        else:
                            target_x = last_valid_target * 0.995 + (w / 2) * 0.005

                # =====================================================
                # LOOK-AHEAD PREDICTION
                # =====================================================
                lookahead.add_position(target_x)
                predicted_target = lookahead.predict(LOOKAHEAD_TREND_WEIGHT)
                if predicted_target is not None:
                    # Blend current target with prediction
                    target_x = 0.7 * target_x + 0.3 * predicted_target

                # =====================================================
                # KALMAN FILTER UPDATE
                # =====================================================
                # Dead zone check
                if abs(target_x - last_target_x) < dead_zone_pixels:
                    target_x = last_target_x
                else:
                    last_target_x = target_x
                
                # Check for CAMERA CUT / LARGE JUMP
                # If the target jumps significantly (e.g. > 30% of screen), 
                # we assume a camera cut and snap instantly.
                current_cam_x, _ = kalman_camera.get_position()
                jump_threshold = w * 0.30
                
                is_cut = False
                if abs(target_x - current_cam_x) > jump_threshold:
                    if has_mediapipe_measurement: # Only snap if we have high confidence detection
                        logging.info(f"[V2] Camera Cut detected! Snapping to {target_x}")
                        kalman_camera.set_position(target_x, h / 2)
                        kalman_camera.set_velocity(0, 0)
                        lookahead.clear()
                        speaker_transition.in_transition = False # Cancel any smooth transition
                        is_cut = True
                
                if not is_cut:
                    # Normal smooth update
                    kalman_camera.predict()
                    if has_mediapipe_measurement or frame_count == 1:
                        kalman_camera.correct(target_x, h / 2)
                
                center_x, _ = kalman_camera.get_position()
                center_x = int(center_x)

                # =====================================================
                # ADAPTIVE ZOOM
                # =====================================================
                if adaptive_zoom and current_face_width > 0:
                    current_crop_w = adaptive_zoom.update(current_face_width, base_crop_w, dt)
                else:
                    current_crop_w = crop_w

                # Ensure crop width is valid
                current_crop_w = max(100, min(current_crop_w, w))
                if current_crop_w % 2 != 0:
                    current_crop_w -= 1

                # =====================================================
                # SAFE CROP CALCULATION
                # =====================================================
                x1 = center_x - current_crop_w // 2
                x2 = x1 + current_crop_w

                if x1 < 0:
                    x1 = 0
                    x2 = current_crop_w
                if x2 > w:
                    x2 = w
                    x1 = w - current_crop_w

                # Final boundary check
                x1 = max(0, min(x1, w - 1))
                x2 = max(x1 + 1, min(x2, w))
                y1 = max(0, min(top_margin, h - 1))
                y2 = min(top_margin + crop_h, h)
                
                actual_crop_w = x2 - x1
                actual_crop_h = y2 - y1
                
                if actual_crop_w < 10 or actual_crop_h < 10:
                    logging.warning(f"[V2] Crop too small: {actual_crop_w}x{actual_crop_h}")
                    prev_gray = gray
                    continue

                cropped = frame[y1:y2, x1:x2]
                
                # Scale to output resolution
                try:
                    scaled = cv2.resize(cropped, (output_w, output_h), interpolation=cv2.INTER_LANCZOS4)
                except Exception as resize_err:
                    logging.error(f"[V2] Resize failed: {resize_err}")
                    prev_gray = gray
                    continue
                
                try:
                    out.write(scaled)
                except Exception as write_err:
                    logging.error(f"[V2] Write failed frame {frame_count}: {write_err}")
                
                # Store for next frame
                prev_gray = gray
            
            except Exception as frame_err:
                logging.error(f"[V2] Error frame {frame_count}: {frame_err}")
                prev_gray = gray if 'gray' in locals() else None
                continue

    except Exception as e:
        logging.error(f"[V2] Fatal error: {e}")
        raise
    
    finally:
        if 'cap' in locals() and cap.isOpened():
            cap.release()
        if 'out' in locals() and out.isOpened():
            out.release()
        logging.info(f"[V2] Face crop finished. Processed {frame_count} frames.")

