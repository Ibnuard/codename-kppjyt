"""
FaceOpticalTracker - Optical flow-based face tracking for smooth camera motion.

Uses Lucas-Kanade optical flow to track feature points inside the face bounding box,
providing continuous position estimates between MediaPipe detections.
"""

import cv2
import numpy as np
from collections import deque


class FaceOpticalTracker:
    """
    Tracks face using Lucas-Kanade optical flow.
    
    Initialize with a face bounding box, then call update() each frame.
    This provides smooth inter-frame tracking without running expensive detection.
    """
    
    # Lucas-Kanade optical flow parameters
    LK_PARAMS = dict(
        winSize=(21, 21),
        maxLevel=3,
        criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 30, 0.01)
    )
    
    # Good features to track parameters
    FEATURE_PARAMS = dict(
        maxCorners=50,
        qualityLevel=0.01,
        minDistance=7,
        blockSize=7
    )
    
    # Minimum points to consider tracking valid
    MIN_TRACKED_POINTS = 10
    
    def __init__(self):
        self.prev_gray = None
        self.feature_points = None
        self.bbox = None
        self.center_x = None
        self.center_y = None
        self.confidence = 0.0
        self.initial_point_count = 0
        
        # Track position history for velocity estimation
        self.position_history = deque(maxlen=5)
        self.velocity_x = 0.0
        self.velocity_y = 0.0
    
    def initialize_from_bbox(self, gray_frame, bbox_x, bbox_y, bbox_w, bbox_h):
        """
        Initialize tracking by detecting feature points inside the face bounding box.
        
        Args:
            gray_frame: Grayscale frame (np.ndarray)
            bbox_x, bbox_y: Top-left corner of face bbox (pixels)
            bbox_w, bbox_h: Width and height of face bbox (pixels)
        
        Returns:
            bool: True if enough points were found to track
        """
        self.bbox = (bbox_x, bbox_y, bbox_w, bbox_h)
        self.prev_gray = gray_frame.copy()
        
        # Create mask limited to face bounding box
        mask = np.zeros(gray_frame.shape, dtype=np.uint8)
        
        # Expand bbox slightly for more stable tracking
        expand = 0.1
        x1 = max(0, int(bbox_x - bbox_w * expand))
        y1 = max(0, int(bbox_y - bbox_h * expand))
        x2 = min(gray_frame.shape[1], int(bbox_x + bbox_w * (1 + expand)))
        y2 = min(gray_frame.shape[0], int(bbox_y + bbox_h * (1 + expand)))
        
        mask[y1:y2, x1:x2] = 255
        
        # Find good features to track within the face region
        points = cv2.goodFeaturesToTrack(gray_frame, mask=mask, **self.FEATURE_PARAMS)
        
        if points is None or len(points) < self.MIN_TRACKED_POINTS:
            self.feature_points = None
            self.confidence = 0.0
            return False
        
        self.feature_points = points
        self.initial_point_count = len(points)
        self.confidence = 1.0
        
        # Set initial center
        self.center_x = bbox_x + bbox_w / 2
        self.center_y = bbox_y + bbox_h / 2
        self.position_history.clear()
        self.position_history.append((self.center_x, self.center_y))
        
        return True
    
    def update(self, gray_frame):
        """
        Track features to the new frame and update estimated face center.
        
        Args:
            gray_frame: Current grayscale frame
            
        Returns:
            tuple: (center_x, center_y, confidence) or (None, None, 0) if tracking failed
        """
        if self.prev_gray is None or self.feature_points is None:
            return None, None, 0.0
        
        if len(self.feature_points) < self.MIN_TRACKED_POINTS:
            self.confidence = 0.0
            return None, None, 0.0
        
        # Track points using optical flow
        new_points, status, err = cv2.calcOpticalFlowPyrLK(
            self.prev_gray,
            gray_frame,
            self.feature_points,
            None,
            **self.LK_PARAMS
        )
        
        if new_points is None:
            self.confidence = 0.0
            return None, None, 0.0
        
        # Filter to only successfully tracked points
        good_mask = status.flatten() == 1
        
        if np.sum(good_mask) < self.MIN_TRACKED_POINTS:
            self.confidence = 0.0
            return None, None, 0.0
        
        good_new = new_points[good_mask]
        good_old = self.feature_points[good_mask]
        
        # Compute movement delta (for updating center estimate)
        delta = good_new - good_old
        median_delta_x = np.median(delta[:, 0, 0])
        median_delta_y = np.median(delta[:, 0, 1])
        
        # Update center based on median movement
        prev_center_x = self.center_x
        prev_center_y = self.center_y
        
        self.center_x += median_delta_x
        self.center_y += median_delta_y
        
        # Update velocity estimate
        self.position_history.append((self.center_x, self.center_y))
        if len(self.position_history) >= 2:
            self.velocity_x = self.center_x - prev_center_x
            self.velocity_y = self.center_y - prev_center_y
        
        # Update confidence based on how many points survived
        self.confidence = len(good_new) / max(self.initial_point_count, 1)
        self.confidence = min(1.0, self.confidence)
        
        # Store for next frame
        self.feature_points = good_new.reshape(-1, 1, 2)
        self.prev_gray = gray_frame.copy()
        
        # Update bbox estimate (rough, based on point spread)
        if len(good_new) > 5:
            pts = good_new.reshape(-1, 2)
            x_min, y_min = pts.min(axis=0)
            x_max, y_max = pts.max(axis=0)
            self.bbox = (x_min, y_min, x_max - x_min, y_max - y_min)
        
        return self.center_x, self.center_y, self.confidence
    
    def get_center_estimate(self):
        """Return current estimated face center."""
        return self.center_x, self.center_y
    
    def get_velocity(self):
        """Return current velocity estimate (pixels/frame)."""
        return self.velocity_x, self.velocity_y
    
    def get_predicted_center(self, frames_ahead=1):
        """
        Predict center position N frames ahead based on velocity.
        
        Args:
            frames_ahead: Number of frames to predict ahead
            
        Returns:
            tuple: (predicted_x, predicted_y)
        """
        if self.center_x is None:
            return None, None
        
        pred_x = self.center_x + self.velocity_x * frames_ahead
        pred_y = self.center_y + self.velocity_y * frames_ahead
        
        return pred_x, pred_y
    
    def reinitialize_if_needed(self, gray_frame, bbox_x, bbox_y, bbox_w, bbox_h, force=False):
        """
        Re-initialize tracking if confidence is too low or forced.
        
        Args:
            gray_frame: Current grayscale frame
            bbox_x, bbox_y, bbox_w, bbox_h: New face bounding box from detection
            force: If True, always reinitialize
            
        Returns:
            bool: True if reinitialized
        """
        should_reinit = (
            force or 
            self.confidence < 0.3 or 
            self.feature_points is None or
            len(self.feature_points) < self.MIN_TRACKED_POINTS
        )
        
        if should_reinit:
            return self.initialize_from_bbox(gray_frame, bbox_x, bbox_y, bbox_w, bbox_h)
        
        # Even if not reinitializing, update prev_gray for continuous tracking
        self.prev_gray = gray_frame.copy()
        
        # Update center to match detection (soft correction)
        detected_cx = bbox_x + bbox_w / 2
        detected_cy = bbox_y + bbox_h / 2
        
        # Blend: 80% detection, 20% tracking (trust detection when available)
        self.center_x = 0.8 * detected_cx + 0.2 * self.center_x
        self.center_y = 0.8 * detected_cy + 0.2 * self.center_y
        
        return False
    
    def is_tracking_valid(self):
        """Check if current tracking state is usable."""
        return (
            self.feature_points is not None and
            len(self.feature_points) >= self.MIN_TRACKED_POINTS and
            self.confidence >= 0.3
        )


class MultiPersonOpticalTracker:
    """
    Manages optical flow trackers for multiple faces.
    
    Each tracked face gets its own FaceOpticalTracker instance.
    """
    
    def __init__(self, max_faces=5):
        self.trackers = {}  # face_id -> FaceOpticalTracker
        self.max_faces = max_faces
    
    def get_or_create_tracker(self, face_id):
        """Get existing tracker or create new one for a face."""
        if face_id not in self.trackers:
            if len(self.trackers) >= self.max_faces:
                # Remove oldest/worst tracker
                worst_id = min(
                    self.trackers.keys(),
                    key=lambda k: self.trackers[k].confidence
                )
                del self.trackers[worst_id]
            
            self.trackers[face_id] = FaceOpticalTracker()
        
        return self.trackers[face_id]
    
    def update_all(self, gray_frame):
        """Update all trackers with the new frame."""
        results = {}
        for face_id, tracker in self.trackers.items():
            cx, cy, conf = tracker.update(gray_frame)
            results[face_id] = (cx, cy, conf)
        return results
    
    def remove_tracker(self, face_id):
        """Remove a tracker for a face that's no longer visible."""
        if face_id in self.trackers:
            del self.trackers[face_id]
    
    def get_tracker(self, face_id):
        """Get tracker for a specific face, or None if not found."""
        return self.trackers.get(face_id)
