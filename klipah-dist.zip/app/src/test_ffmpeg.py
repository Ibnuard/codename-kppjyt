import os
import subprocess

def test_concat():
    # create dummy red video
    subprocess.run(["ffmpeg", "-y", "-f", "lavfi", "-i", "color=c=red:s=1080x1920:d=3", "-f", "lavfi", "-i", "anullsrc=r=44100:cl=stereo", "-c:v", "libx264", "-c:a", "aac", "red.mp4"])
    # create dummy blue video
    subprocess.run(["ffmpeg", "-y", "-f", "lavfi", "-i", "color=c=blue:s=1080x1920:d=3", "-f", "lavfi", "-i", "anullsrc=r=44100:cl=stereo", "-c:v", "libx264", "-c:a", "aac", "blue.mp4"])
    # create dummy green video
    subprocess.run(["ffmpeg", "-y", "-f", "lavfi", "-i", "color=c=green:s=1080x1920:d=1", "-f", "lavfi", "-i", "anullsrc=r=44100:cl=stereo", "-c:v", "libx264", "-c:a", "aac", "green.mp4"])
    
    # Try overlay at 2.5s
    overlay_start = 2.5
    trans_duration = 1.0
    
    # The fix uses -itsoffset for input 2, OR setpts in filter
    
    # Let's test filter delay approach:
    cmd = [
        "ffmpeg", "-y",
        "-i", "red.mp4",
        "-i", "blue.mp4",
        "-i", "green.mp4",
        "-i", "green.mp4", # sfx dummy
        "-filter_complex",
        f"[0:v]fps=30,setsar=1[v0];"
        f"[1:v]fps=30,setsar=1[v1];"
        f"[0:a]anull[a0];[1:a]anull[a1];"
        f"[v0][a0][v1][a1]concat=n=2:v=1:a=1[basev][basea];"
        # Delay the green video using setpts
        f"[2:v]scale=1080:1920,setsar=1,setpts=PTS-STARTPTS+{overlay_start}/TB[keyed_delayed];"
        f"[basev][keyed_delayed]overlay=x=0:y=0:eof_action=pass[outv];"
        f"[3:a]adelay=delays={int(overlay_start*1000)}[delayed_sfx];"
        f"[basea][delayed_sfx]amix=inputs=2:duration=first[outa]",
        "-map", "[outv]",
        "-map", "[outa]",
        "-c:v", "libx264", "output.mp4"
    ]
    subprocess.run(cmd)

if __name__ == "__main__":
    test_concat()
