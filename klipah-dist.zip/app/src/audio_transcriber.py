from faster_whisper import WhisperModel
import logging
import os
import torch
from .utils import check_ffmpeg

# Model cache to avoid reloading on every call
_model_cache = {}

def transcribe_audio_file(
    file_path,
    model_size="small",
    language="id",
    **kwargs  # Accept extra args for backward compatibility
):
    """
    Transcribe an audio file using faster-whisper (CTranslate2).
    
    Args:
        file_path: Path to audio/video file
        model_size: Whisper model size (default: small)
        language: Language code (default: id for Indonesian)
    
    Returns:
        Result in OpenAI Whisper format for backward compatibility.
    """
    if not check_ffmpeg():
        raise RuntimeError("FFmpeg is required for Whisper but was not found.")

    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")

    # --- GPU Check ---
    if torch.cuda.is_available():
        device = "cuda"
        compute_type = "float16"  # Faster on GPU
    else:
        device = "cpu"
        compute_type = "int8"  # Faster on CPU
        logging.warning(
            "CUDA tidak tersedia — Whisper akan jalan di CPU (lebih lambat)."
        )

    # Use 'small' model for reliability
    actual_model = 'small'
    
    # Cache model to avoid reloading
    cache_key = f"{actual_model}_{device}_{compute_type}"
    if cache_key not in _model_cache:
        logging.info(f"Loading faster-whisper model '{actual_model}' on {device} ({compute_type})...")
        try:
            _model_cache[cache_key] = WhisperModel(
                actual_model,
                device=device,
                compute_type=compute_type
            )
        except Exception as e:
            logging.error(f"Failed to load faster-whisper model: {e}")
            raise
    
    model = _model_cache[cache_key]
    logging.info(f"Transcribing {file_path} with faster-whisper...")

    # Transcribe with word timestamps
    segments, info = model.transcribe(
        file_path,
        language=language,
        word_timestamps=True,
        beam_size=5,
        vad_filter=True,  # Filter out silence for faster processing
        vad_parameters=dict(min_silence_duration_ms=500)
    )

    # Convert to OpenAI Whisper format for backward compatibility
    result_segments = []
    full_text = []
    
    for segment in segments:
        seg_data = {
            "id": segment.id,
            "seek": int(segment.seek) if hasattr(segment, 'seek') else 0,
            "start": segment.start,
            "end": segment.end,
            "text": segment.text,
            "tokens": [],
            "temperature": 0.0,
            "avg_logprob": segment.avg_logprob if hasattr(segment, 'avg_logprob') else 0,
            "compression_ratio": segment.compression_ratio if hasattr(segment, 'compression_ratio') else 0,
            "no_speech_prob": segment.no_speech_prob if hasattr(segment, 'no_speech_prob') else 0,
        }
        
        # Add word-level timestamps
        if segment.words:
            seg_data["words"] = [
                {
                    "word": word.word,
                    "start": word.start,
                    "end": word.end,
                    "probability": word.probability
                }
                for word in segment.words
            ]
        
        result_segments.append(seg_data)
        full_text.append(segment.text)

    result = {
        "text": "".join(full_text),
        "segments": result_segments,
        "language": info.language
    }

    return result
