import logging
from youtube_transcript_api import YouTubeTranscriptApi, TranscriptsDisabled, NoTranscriptFound
import yt_dlp
import os
from .utils import get_safe_filename, strip_ansi

def extract_video_id(url):
    """Extract YouTube video ID from URL."""
    # Basic extraction, can be improved with regex or urllib
    if "v=" in url:
        return url.split("v=")[1].split("&")[0]
    elif "youtu.be/" in url:
        return url.split("youtu.be/")[1].split("?")[0]
    return url

def download_audio(url, output_dir="temp_audio", progress_callback=None):
    """
    Download audio from a YouTube video using yt-dlp.
    Returns the path to the downloaded audio file.
    """
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    def progress_hook(d):
        if progress_callback and d['status'] == 'downloading':
            p = strip_ansi(d.get('_percent_str', '0%')).strip()
            s = strip_ansi(d.get('_speed_str', 'N/A')).strip()
            e = strip_ansi(d.get('_eta_str', 'N/A')).strip()
            progress_callback(f"Downloading Audio... {p} ({s}, ETA: {e})")
        elif progress_callback and d['status'] == 'finished':
            progress_callback("Audio download complete. Processing...")

    ydl_opts = {
        'format': 'bestaudio/best',
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192',
        }],
        'outtmpl': f'{output_dir}/%(title)s.%(ext)s',
        'quiet': True,
        'no_warnings': True,
        'progress_hooks': [progress_hook],
        'no_color': True,
    }

    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info_dict = ydl.extract_info(url, download=True)
        filename = ydl.prepare_filename(info_dict)
        # yt-dlp with postprocessor changes extension to mp3
        final_filename = os.path.splitext(filename)[0] + ".mp3" 
        return final_filename, info_dict.get('title', 'Unknown Title')

def get_youtube_transcript(url, lang_code='en'):
    """
    Try to fetch existing manual or auto-generated transcript.
    Returns a list of dictionaries with text, start, and duration.
    """
    video_id = extract_video_id(url)
    try:
        # Instantiate the API
        yt = YouTubeTranscriptApi()
        transcript_list = yt.list(video_id)
        
        transcript = None
        
        # 1. Try manual in 'id', 'en', 'en-US'
        try:
            transcript = transcript_list.find_manually_created_transcript(['id', 'en', 'en-US', 'en-GB'])
        except Exception:
            pass

        # 2. Try generated in 'id', 'en'
        if not transcript:
            try:
                transcript = transcript_list.find_generated_transcript(['id', 'en', 'en-US', 'en-GB'])
            except Exception:
                pass

        # 3. Fallback: First available Indonesian or English
        if not transcript:
            try:
                transcript = transcript_list.find_generated_transcript(['id'])
            except Exception:
                pass
        
        # If still nothing, just return any?
        # Let's rely on what we found.

        if transcript:
            logging.info(f"Found transcript: {transcript.language_code}")
            return transcript.fetch().to_raw_data()
        else:
            # Try just fetching default?
            # yt.fetch(video_id) might work
             return yt.fetch(video_id).to_raw_data()

    except (TranscriptsDisabled, NoTranscriptFound) as e:
        logging.info(f"Could not retrieve existing transcript: {e}")
        return None
        

    except Exception as e:
        logging.error(f"Error fetching transcript: {e}")
        return None

def download_video(url, output_dir="temp_video", resolution="1080", progress_callback=None):
    """
    Download video from YouTube using yt-dlp.
    Returns path to downloaded file and title.
    """
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
        
    # Standardize resolution height
    height = resolution.replace("p", "")
    
    # Format logic: 
    # Prioritize MP4. Get best video with height <= selected height + best audio.
    fmt = f'bestvideo[height<={height}][ext=mp4]+bestaudio[ext=m4a]/best[height<={height}][ext=mp4]/best'
    
    def progress_hook(d):
        if progress_callback and d['status'] == 'downloading':
            p = strip_ansi(d.get('_percent_str', '0%')).strip()
            s = strip_ansi(d.get('_speed_str', 'N/A')).strip()
            e = strip_ansi(d.get('_eta_str', 'N/A')).strip()
            progress_callback(f"Downloading Video... {p} ({s}, ETA: {e})")
        elif progress_callback and d['status'] == 'finished':
            progress_callback("Video download complete. Merging formats...")

    ydl_opts = {
        'format': fmt,
        'outtmpl': f'{output_dir}/%(title)s.%(ext)s',
        'quiet': True,
        'no_warnings': True,
        'progress_hooks': [progress_hook],
        'no_color': True,
    }
    
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=True)
        filename = ydl.prepare_filename(info)
        
        # Verify file exists, sometimes post-processing changes it (though mp4 usually stays mp4)
        if not os.path.exists(filename):
            # Check for possible merged extension if different
            base, _ = os.path.splitext(filename)
            for ext in ['.mp4', '.mkv', '.webm']:
                if os.path.exists(base + ext):
                    filename = base + ext
                    break
        
        return filename, info.get('title', 'Unknown')


def get_channel_info(url, output_dir="temp_video"):
    """
    Extract channel information from a YouTube video URL.
    Downloads channel avatar and returns channel name.
    
    Args:
        url: YouTube video URL
        output_dir: Directory to save channel avatar
        
    Returns:
        dict: {
            'channel_name': '@channel_handle or channel name',
            'channel_id': channel ID,
            'avatar_path': path to downloaded avatar image (or None)
        }
    """
    import requests
    
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    try:
        ydl_opts = {
            'quiet': True,
            'no_warnings': True,
            'skip_download': True,
        }
        
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            
            # Get channel info
            channel_name = info.get('uploader', 'Unknown')
            channel_id = info.get('channel_id', '')
            channel_url = info.get('channel_url', '')
            uploader_id = info.get('uploader_id', '')  # This is often @handle
            
            # Prefer @handle if available
            if uploader_id and uploader_id.startswith('@'):
                display_name = uploader_id
            elif uploader_id:
                display_name = f"@{uploader_id}"
            else:
                display_name = f"@{channel_name.replace(' ', '')}"
            
            # Get channel thumbnail/avatar
            # yt-dlp provides channel thumbnail in 'thumbnails' or we can construct it
            avatar_url = None
            avatar_path = None
            
            # Try to get channel avatar from video info
            # YouTube channel avatars can be accessed via channel ID
            if channel_id:
                # YouTube channel avatar URL pattern
                avatar_url = f"https://yt3.googleusercontent.com/ytc/{channel_id}=s176-c-k-c0x00ffffff-no-rj"
                
            # Also check if there's a channel thumbnail in the info
            if 'channel_thumbnail' in info:
                avatar_url = info['channel_thumbnail']
            
            # For channel avatar, we might need to fetch from channel page
            # Let's try to get it from the uploader_url
            if not avatar_url and channel_url:
                try:
                    # Extract channel info for avatar
                    channel_info = ydl.extract_info(channel_url, download=False, process=False)
                    if channel_info and 'thumbnails' in channel_info:
                        # Get smallest thumbnail (usually avatar)
                        for thumb in channel_info['thumbnails']:
                            if thumb.get('width', 0) <= 200:
                                avatar_url = thumb['url']
                                break
                except Exception:
                    pass
            
            # Download avatar if we have URL
            if avatar_url:
                try:
                    avatar_filename = f"channel_avatar_{channel_id or 'unknown'}.jpg"
                    avatar_path = os.path.join(output_dir, avatar_filename)
                    
                    response = requests.get(avatar_url, timeout=10)
                    if response.status_code == 200:
                        with open(avatar_path, 'wb') as f:
                            f.write(response.content)
                        logging.info(f"Downloaded channel avatar to {avatar_path}")
                    else:
                        avatar_path = None
                except Exception as e:
                    logging.warning(f"Could not download channel avatar: {e}")
                    avatar_path = None
            
            return {
                'channel_name': display_name,
                'channel_id': channel_id,
                'avatar_path': avatar_path,
                'full_name': channel_name
            }
            
    except Exception as e:
        logging.error(f"Error getting channel info: {e}")
        return {
            'channel_name': '@unknown',
            'channel_id': None,
            'avatar_path': None,
            'full_name': 'Unknown'
        }

