import os
import logging
import textwrap
from datetime import timedelta
from .utils import get_font_path, get_font_dir

def format_timedelta(seconds):
    """Format seconds into SRT timestamp format (HH:MM:SS,mmm)."""
    td = timedelta(seconds=seconds)
    total_seconds = int(td.total_seconds())
    hours = total_seconds // 3600
    minutes = (total_seconds % 3600) // 60
    secs = total_seconds % 60
    millis = int(td.microseconds / 1000)
    return f"{hours:02}:{minutes:02}:{secs:02},{millis:03}"

def generate_srt(transcript_segments, output_srt_path, start_offset=0, end_offset=None):
    """
    Generate creator-style SRT from Whisper word timestamps:
    - Dynamic chunking (bukan kaku 2 kata)
    - Flow lebih natural seperti TikTok/Reels
    - Punchy emphasis (ALL CAPS)
    - Karaoke style highlighting (Current Word: Yellow, Others: White)
    """
    srt_content = ""
    index = 1

    # -------- 1) FLATTEN ALL WORDS ----------
    all_words = []
    for seg in transcript_segments:
        if 'words' in seg:
            for w in seg['words']:
                all_words.append(w)
        else:
            # Fallback
            text_words = seg['text'].strip().split()
            duration = seg['end'] - seg['start']
            word_dur = duration / max(1, len(text_words))
            for i, word in enumerate(text_words):
                all_words.append({
                    'start': seg['start'] + i * word_dur,
                    'end': seg['start'] + (i + 1) * word_dur,
                    'word': word
                })

    # -------- 2) DYNAMIC CHUNKING (ANTI-KAKU) ----------
    chunks = []
    current_chunk = []
    # Short punchy lines: ~20 chars max or punctuation
    max_chars = 18   
    
    for w in all_words:
        word_text = w['word'].strip()
        current_chunk.append(w)
        
        # Check current length
        preview = " ".join([x['word'] for x in current_chunk])
        
        # Break if too long or hits punctuation
        if len(preview) >= max_chars or word_text.endswith((".", "!", "?", ",", ";", ":")):
            chunks.append(current_chunk)
            current_chunk = []

    if current_chunk:
        chunks.append(current_chunk)

    # -------- 3) BUILD KARAOKE SRT ----------
    for chunk in chunks:
        # Loop over each word in the chunk to create dynamic highlighting
        for i, active_word in enumerate(chunk):
            s = float(active_word['start'])
            
            # Determine end time: start of next word (seamless) or own end if last
            if i < len(chunk) - 1:
                e = float(chunk[i+1]['start'])
            else:
                e = float(active_word['end'])

            if e <= start_offset or (end_offset and s >= end_offset):
                continue

            seg_start = max(0, s - start_offset)
            seg_end = e - start_offset
            if end_offset:
                seg_end = min(seg_end, end_offset - start_offset)

            if seg_end <= seg_start:
                continue

            # BUILD TEXT WITH HIGHLIGHT
            line_parts = []
            for j, w in enumerate(chunk):
                word_clean = w['word'].strip().upper()
                if i == j:
                    # Active word: Yellow (Match intro)
                    line_parts.append(f'<font color="#FFE13C">{word_clean}</font>')
                else:
                    # Inactive: White
                    line_parts.append(word_clean)
            
            text = " ".join(line_parts)

            srt_content += f"{index}\n"
            srt_content += f"{format_timedelta(seg_start)} --> {format_timedelta(seg_end)}\n"
            srt_content += f"{text}\n\n"
            index += 1

    with open(output_srt_path, "w", encoding="utf-8") as f:
        f.write(srt_content)
    
    return output_srt_path

def get_burn_subtitles_filter(srt_path):
    """
    Return FFmpeg subtitle filter with premium styling (TikTok/Shorts style).
    """
    # Fix paths for FFmpeg on Windows: Use absolute paths, forward slashes, and escape the colon
    abs_path = os.path.abspath(srt_path)
    escaped_path = abs_path.replace("\\", "/").replace(":", "\\:")
    
    logging.info(f"Subtitle path for FFmpeg: {escaped_path}")

    # Viral Shorts Style — use centralized font dir (handles frozen apps)
    escaped_font_dir = get_font_dir(escaped=True)
    
    style = (
        "FontName=Montserrat ExtraBold,"
        "FontSize=16,"              # Smaller but readable (Match intro/shorts feel)
        "PrimaryColour=&H00FFFFFF," # White (Default for inactive words)
        "OutlineColour=&H000000,"   # Black Outline
        "Outline=1.2,"                # Balanced outline
        "Shadow=0.8,"                 # Soft shadow
        "Alignment=2,"              # Bottom Center
        "MarginV=60,"               # Position
        "Spacing=1.1,"              # Slight letter spacing
        "Blur=0.6"                  # Slight blur
    )
    
    return f"subtitles='{escaped_path}':fontsdir='{escaped_font_dir}':force_style='{style}'"


def get_credit_overlay_filter(channel_name, logo_path=None, position="top_right"):
    """
    Create FFmpeg filter for creator credit overlay (logo + channel name).
    
    Args:
        channel_name: Channel/creator name to display (e.g., "@channel_name")
        logo_path: Optional path to logo image (PNG recommended with transparency)
        position: Position on screen ("top_right", "top_left", "bottom_right", "bottom_left")
    
    Returns:
        str: FFmpeg filter string for credit overlay
    """
    filters = []
    
    # Position calculations (based on common 1080x1920 vertical video)
    positions = {
        "top_right": {"x": "W-w-30", "y": "30"},
        "top_left": {"x": "30", "y": "30"},
        "bottom_right": {"x": "W-w-30", "y": "H-h-150"},  # Above subtitles
        "bottom_left": {"x": "30", "y": "H-h-150"},
    }
    
    pos = positions.get(position, positions["top_right"])
    
    # Channel name text overlay
    # Clean the channel name and escape special characters
    safe_channel = channel_name.replace("'", "\\'").replace(":", "\\:")
    
    # Build drawtext filter for channel name
    # Style: Semi-transparent background pill with white text
    escaped_font = get_font_path(escaped=True)
    text_filter = (
        f"drawtext="
        f"text='{safe_channel}':"
        f"fontfile='{escaped_font}':"
        f"fontsize=24:"
        f"fontcolor=white:"
        f"x={pos['x']}:"
        f"y={pos['y']}+50:"  # Below logo position
        f"box=1:"
        f"boxcolor=black@0.5:"
        f"boxborderw=8"
    )
    
    # If logo provided, overlay it above the channel name
    if logo_path and os.path.exists(logo_path):
        # Escape path for FFmpeg
        escaped_logo = logo_path.replace("\\", "/").replace(":", "\\:")
        
        # Logo overlay (resize to 80x80 and position)
        logo_filter = (
            f"[1:v]scale=80:80[logo];"
            f"[0:v][logo]overlay={pos['x']}:{pos['y']}"
        )
        filters.append(logo_filter)
        
    filters.append(text_filter)
    
    return ",".join(filters) if len(filters) == 1 else filters


def get_combined_video_filter(srt_path=None, channel_name=None, logo_path=None):
    """
    Get combined FFmpeg filter for subtitles + credit overlay.
    
    Args:
        srt_path: Path to SRT subtitle file
        channel_name: Channel name for credit overlay
        logo_path: Path to logo image for credit overlay
    
    Returns:
        str: Combined FFmpeg filter string
    """
    filters = []
    
    if srt_path:
        filters.append(get_burn_subtitles_filter(srt_path))
    
    if channel_name:
        credit_filter = get_credit_overlay_filter(channel_name, logo_path)
        if isinstance(credit_filter, list):
            filters.extend(credit_filter)
        else:
            filters.append(credit_filter)
    
    return ",".join(filters) if filters else None

