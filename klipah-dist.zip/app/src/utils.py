import shutil
import logging
import os
import sys
import re

def check_ffmpeg():
    """Check if FFmpeg is installed and accessible in the system PATH.
       If not, try to find it in common Winget locations and add it to PATH."""
    
    if shutil.which("ffmpeg"):
        return True

    # Try to find it in Winget location
    logging.info("FFmpeg not found in PATH. Searching in common locations...")
    
    # Common base paths for Winget packages + LOCAL BIN
    possible_bases = [
        os.path.join(os.path.dirname(os.path.dirname(__file__)), "bin"), # Backend/bin
        os.path.join(os.environ.get("LOCALAPPDATA"), "Microsoft", "WinGet", "Packages"),
        "C:\\Program Files",
        "C:\\Program Files (x86)"
    ]

    for base in possible_bases:
        if not os.path.exists(base):
            continue
            
        # Walk to find ffmpeg.exe
        for root, dirs, files in os.walk(base):
            if "ffmpeg.exe" in files:
                ffmpeg_path = os.path.dirname(os.path.join(root, "ffmpeg.exe"))
                logging.info(f"Found FFmpeg at: {ffmpeg_path}")
                
                # Add to PATH for this process
                os.environ["PATH"] += os.pathsep + ffmpeg_path
                return True
                
    logging.error("FFmpeg not found. Please install FFmpeg to use this tool fully (required for Whisper and some yt-dlp features).")
    return False

def get_safe_filename(title):
    """Sanitize a string to be used as a filename."""
    keepcharacters = (' ','.','_')
    return "".join(c for c in title if c.isalnum() or c in keepcharacters).rstrip()

def strip_ansi(text):
    """Remove ANSI escape sequences from a string."""
    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
    return ansi_escape.sub('', text)


FONT_FILENAME = "Montserrat-ExtraBold.ttf"
FONT_SUBDIR = "fonts"  # Dedicated font directory to avoid libass scanning non-font files

def get_src_dir():
    """Get the src directory path, compatible with PyInstaller frozen apps."""
    if getattr(sys, 'frozen', False):
        # Running as compiled (PyInstaller)
        return sys._MEIPASS
    return os.path.dirname(os.path.abspath(__file__))

def get_font_path(escaped=False):
    """
    Get the absolute path to the custom Montserrat font file.
    
    Args:
        escaped: If True, return FFmpeg-compatible escaped path (forward slashes, escaped colons)
    
    Returns:
        str: Path to the font file
    
    Raises:
        FileNotFoundError: If the font file does not exist
    """
    font_path = os.path.join(get_src_dir(), FONT_SUBDIR, FONT_FILENAME)
    
    if not os.path.exists(font_path):
        logging.error(f"Custom font not found: {font_path}")
        raise FileNotFoundError(
            f"Font file '{FONT_FILENAME}' not found at '{font_path}'. "
            f"Ensure the font is bundled in the {FONT_SUBDIR}/ directory."
        )
    
    if escaped:
        return font_path.replace('\\', '/').replace(':', '\\:')
    return font_path

def get_font_dir(escaped=False):
    """
    Get the dedicated fonts directory, for FFmpeg fontsdir.
    Only contains font files to avoid libass scanning non-font files.
    
    Args:
        escaped: If True, return FFmpeg-compatible escaped path
    
    Returns:
        str: Directory path containing fonts
    """
    font_dir = os.path.join(get_src_dir(), FONT_SUBDIR)
    abs_font_dir = os.path.abspath(font_dir)
    if escaped:
        return abs_font_dir.replace('\\', '/').replace(':', '\\:')
    return abs_font_dir
