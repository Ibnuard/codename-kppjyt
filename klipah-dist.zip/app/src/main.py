import argparse
import logging
import json
import os
from .youtube_extractor import get_youtube_transcript, download_audio
from .audio_transcriber import transcribe_audio_file
from .utils import check_ffmpeg

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def normalize_transcript(data):
    """
    Normalize transcript data to a standard format:
    {
        "meta": { "timeScale": "seconds", "source": "..." },
        "content": [ { "start": float, "end": float, "text": string } ]
    }
    """
    content = []
    source = "Unknown"

    # Case 1: Whisper Output (dict with 'segments')
    if isinstance(data, dict) and 'segments' in data:
        source = "Whisper Transcription"
        for segment in data['segments']:
            content.append({
                "start": round(segment.get('start', 0), 2),
                "end": round(segment.get('end', 0), 2),
                "text": segment.get('text', '').strip()
            })
    
    # Case 2: YouTube Transcript API (list of dicts with 'duration')
    elif isinstance(data, list) and len(data) > 0 and 'duration' in data[0]:
        source = "YouTube Caption"
        for item in data:
            start = float(item.get('start', 0))
            duration = float(item.get('duration', 0))
            content.append({
                "start": round(start, 2),
                "end": round(start + duration, 2),
                "text": item.get('text', '').strip()
            })
            
    # Case 3: Already normalized or simple text (fallback)
    elif isinstance(data, dict) and 'text' in data: # Simple Whisper text only?
         source = "Whisper Text"
         return data # Return as is if we can't parse segments? Or maybe just text.
    
    return {
        "meta": {
            "source": source,
            "timeScale": "seconds",
            "description": "Start and End times are in seconds."
        },
        "content": content
    }

def save_transcript(data, output_path, format='json'):
    """Save transcript data to file."""
    
    # Normalize data if saving to JSON
    if format == 'json':
        normalized_data = normalize_transcript(data)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(normalized_data, f, indent=4, ensure_ascii=False)
            
    else:
        # Simple text format (txt)
        with open(output_path, 'w', encoding='utf-8') as f:
            if isinstance(data, list): # YouTube transcript format
                for item in data:
                    f.write(f"{item['text']}\n")
            elif isinstance(data, dict) and 'text' in data: # Whisper format
                f.write(data['text'])
            elif isinstance(data, dict) and 'content' in data: # Normalized format (re-saving?)
                for item in data['content']:
                    f.write(f"{item['text']}\n")

    logging.info(f"Transcript saved to {output_path}")

def main():
    # Ensure FFmpeg is available (finds it via Winget if needed)
    check_ffmpeg()

    parser = argparse.ArgumentParser(description="Extract transcript from YouTube URL or local file.")
    parser.add_argument("--url", help="YouTube video URL")
    parser.add_argument("--file", help="Path to local audio/video file")
    parser.add_argument("--output", help="Output file path (default: transcript.json)")
    parser.add_argument("--model", default="base", help="Whisper model size (tiny, base, small, medium, large)")
    parser.add_argument("--force-download", action="store_true", help="Force download audio even if transcript exists (for YouTube)")
    parser.add_argument("--auto-intro", action="store_true", help="Automatically generate intro for clips")
    parser.add_argument("--use-transition", action="store_true", help="Use greenscreen transition between intro and main video")
    parser.add_argument("--gui", action="store_true", help="Launch Graphical User Interface")
    
    args = parser.parse_args()

    # Launch GUI if requested or no arguments provided (and not asking for help)
    if args.gui or (not args.url and not args.file):
        try:
            from .gui import launch_gui
            launch_gui()
            return
        except ImportError as e:
            logging.error(f"Could not import GUI: {e}")
            return

    if not args.url and not args.file:
        parser.error("Please provide either --url or --file, or use --gui")

    transcript_data = None


    if args.url:
        logging.info(f"Processing YouTube URL: {args.url}")
        
        # 1. Try to get existing transcript first (unless forced download)
        if not args.force_download:
            logging.info("Attempting to fetch existing captions...")
            transcript_data = get_youtube_transcript(args.url)
        
        # 2. If no transcript found or forced download, download audio and transcribe
        if not transcript_data:
            if not args.force_download:
                logging.warning("No existing captions found. Falling back to audio download and transcription.")
            
            audio_path = None
            try:
                logging.info("Downloading audio from YouTube...")
                audio_path, title = download_audio(args.url)
                logging.info(f"Audio downloaded: {audio_path}")
                
                transcript_data = transcribe_audio_file(audio_path, model_size=args.model)
                
            except Exception as e:
                logging.error(f"Failed to process YouTube video: {e}")
                return
            finally:
                # Cleanup audio file if it exists
                if audio_path and os.path.exists(audio_path):
                    try:
                        os.remove(audio_path)
                        logging.info(f"Temporary audio file removed: {audio_path}")
                    except Exception as cleanup_error:
                        logging.warning(f"Failed to remove temp file: {cleanup_error}")

    elif args.file:
        logging.info(f"Processing local file: {args.file}")
        try:
            transcript_data = transcribe_audio_file(args.file, model_size=args.model)
        except Exception as e:
            logging.error(f"Failed to transcribe file: {e}")
            return

    if transcript_data:
        output_path = args.output if args.output else "transcript.json"
        save_transcript(transcript_data, output_path, format='json' if output_path.endswith('.json') else 'txt')
        
if __name__ == "__main__":
    main()
