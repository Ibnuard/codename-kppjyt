import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import threading
import logging
import queue
import os
import json
from .main import get_youtube_transcript, download_audio, transcribe_audio_file, save_transcript
from .youtube_extractor import download_video
from .utils import check_ffmpeg
from .highlight_extractor import extract_highlights
from .video_clipper import clip_video

class QueueHandler(logging.Handler):
    """Class to send logging records to a queue"""
    def __init__(self, log_queue):
        super().__init__()
        self.log_queue = log_queue

    def emit(self, record):
        self.log_queue.put(record)

class TranscriptApp:
    def __init__(self, root):
        # Initialize env
        check_ffmpeg()
        
        self.root = root
        self.root.title("YouTube & Audio Transcript Extractor")
        self.root.geometry("600x500")

        # Layout
        self.notebook = ttk.Notebook(root)
        self.notebook.pack(pady=10, expand=True, fill="both")

        # Frames
        self.yt_frame = ttk.Frame(self.notebook, padding=10)
        self.file_frame = ttk.Frame(self.notebook, padding=10)
        self.ai_frame = ttk.Frame(self.notebook, padding=10)
        self.clip_frame = ttk.Frame(self.notebook, padding=10)
        
        self.notebook.add(self.yt_frame, text="YouTube URL")
        self.notebook.add(self.file_frame, text="Local File")
        self.notebook.add(self.ai_frame, text="AI Highlights")
        self.notebook.add(self.clip_frame, text="Clipper")

        # --- YouTube Tab ---
        ttk.Label(self.yt_frame, text="YouTube URL:").pack(anchor=tk.W)
        self.url_entry = ttk.Entry(self.yt_frame, width=50)
        self.url_entry.pack(fill=tk.X, pady=5)
        
        self.force_dl_var = tk.BooleanVar()
        ttk.Checkbutton(self.yt_frame, text="Force Download Audio (Ignore captions)", variable=self.force_dl_var).pack(anchor=tk.W)

        # --- File Tab ---
        ttk.Label(self.file_frame, text="Audio/Video File:").pack(anchor=tk.W)
        self.file_entry = ttk.Entry(self.file_frame, width=40)
        self.file_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, pady=5)
        ttk.Button(self.file_frame, text="Browse", command=self.browse_file).pack(side=tk.RIGHT, padx=5)

        # --- AI Highlights Tab ---
        ttk.Label(self.ai_frame, text="Input Transcript JSON:").pack(anchor=tk.W)
        self.json_entry = ttk.Entry(self.ai_frame, width=40)
        self.json_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, pady=5)
        ttk.Button(self.ai_frame, text="Browse", command=self.browse_json).pack(side=tk.RIGHT, padx=5)

        # --- Clipper Tab ---
        # 1. Highlights JSON Input
        ttk.Label(self.clip_frame, text="Load Highlights JSON:").pack(anchor=tk.W)
        hl_frame = ttk.Frame(self.clip_frame)
        hl_frame.pack(fill=tk.X, pady=5)
        self.hl_json_entry = ttk.Entry(hl_frame, width=40)
        self.hl_json_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(hl_frame, text="Browse & Load", command=self.browse_and_load_highlights).pack(side=tk.RIGHT, padx=5)
        
        # 2. Clips List (Treeview)
        ttk.Label(self.clip_frame, text="Select Clips to Process:").pack(anchor=tk.W)
        self.clip_tree = ttk.Treeview(self.clip_frame, columns=("check", "start", "end", "title"), show="headings", height=5)
        self.clip_tree.heading("check", text="Sel")
        self.clip_tree.heading("start", text="Start")
        self.clip_tree.heading("end", text="End")
        self.clip_tree.heading("title", text="Title")
        self.clip_tree.column("check", width=30, anchor="center")
        self.clip_tree.column("start", width=60)
        self.clip_tree.column("end", width=60)
        self.clip_tree.column("title", width=200)
        self.clip_tree.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # 3. Source Selection
        ttk.Label(self.clip_frame, text="Source Video:").pack(anchor=tk.W)
        self.source_var = tk.StringVar(value="url")
        
        # Source: YouTube URL input specific to clipper
        src_frame = ttk.Frame(self.clip_frame)
        src_frame.pack(fill=tk.X)
        
        ttk.Radiobutton(src_frame, text="YouTube URL", variable=self.source_var, value="url").pack(anchor=tk.W)
        self.clip_url_entry = ttk.Entry(src_frame, width=40)
        self.clip_url_entry.pack(fill=tk.X, padx=20)
        
        ttk.Radiobutton(src_frame, text="Local Video File", variable=self.source_var, value="file").pack(anchor=tk.W)
        self.clip_file_entry = ttk.Entry(src_frame, width=40)
        self.clip_file_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=20)
        ttk.Button(src_frame, text="Browse", command=self.browse_clip_source).pack(side=tk.RIGHT)

        # --- Common Options (Bottom) ---
        options_frame = ttk.LabelFrame(root, text="Options", padding=10)
        options_frame.pack(fill=tk.X, padx=10, pady=5)

        ttk.Label(options_frame, text="Whisper Model:").grid(row=0, column=0, padx=5, sticky=tk.W)
        self.model_var = tk.StringVar(value="base")
        model_combo = ttk.Combobox(options_frame, textvariable=self.model_var, values=["tiny", "base", "small", "medium", "large"], state="readonly", width=10)
        model_combo.grid(row=0, column=1, padx=5, sticky=tk.W)

        ttk.Label(options_frame, text="Output Directory:").grid(row=1, column=0, padx=5, sticky=tk.W)
        self.out_dir_var = tk.StringVar(value=os.getcwd())
        ttk.Entry(options_frame, textvariable=self.out_dir_var).grid(row=1, column=1, padx=5, sticky=tk.EW)
        ttk.Button(options_frame, text="Browse", command=self.browse_out_dir).grid(row=1, column=2, padx=5)
        
        options_frame.columnconfigure(1, weight=1)

        # Action Button
        self.run_btn = ttk.Button(root, text="Extract Transcript", command=self.start_extraction)
        self.run_btn.pack(pady=10)

        # Log Window
        self.log_area = scrolledtext.ScrolledText(root, state='disabled', height=10)
        self.log_area.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        # Logging Setup
        self.log_queue = queue.Queue()
        queue_handler = QueueHandler(self.log_queue)
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        queue_handler.setFormatter(formatter)
        logging.getLogger().addHandler(queue_handler)
        
        # Start polling log queue
        self.root.after(100, self.poll_log_queue)
        
        # Setup bindings
        self.setup_bindings()

    def browse_file(self):
        filename = filedialog.askopenfilename(filetypes=[("Media Files", "*.mp3 *.wav *.mp4 *.mkv *.m4a"), ("All Files", "*.*")])
        if filename:
            self.file_entry.delete(0, tk.END)
            self.file_entry.insert(0, filename)

    def browse_json(self):
        filename = filedialog.askopenfilename(filetypes=[("JSON Files", "*.json"), ("All Files", "*.*")])
        if filename:
            self.json_entry.delete(0, tk.END)
            self.json_entry.insert(0, filename)

    def browse_out_dir(self):
        dirname = filedialog.askdirectory()
        if dirname:
            self.out_dir_var.set(dirname)

    def poll_log_queue(self):
        try:
            while True:
                record = self.log_queue.get_nowait()
                msg = self.log_handler.format(record) if hasattr(self, 'log_handler') else record.getMessage() # simplified
                self.log_area.configure(state='normal')
                self.log_area.insert(tk.END, msg + '\n')
                self.log_area.see(tk.END)
                self.log_area.configure(state='disabled')
        except queue.Empty:
            pass
        self.root.after(100, self.poll_log_queue)

    def browse_and_load_highlights(self):
        filename = filedialog.askopenfilename(filetypes=[("JSON Files", "*.json"), ("All Files", "*.*")])
        if filename:
            self.hl_json_entry.delete(0, tk.END)
            self.hl_json_entry.insert(0, filename)
            self.load_highlights_to_tree(filename)

    def browse_clip_source(self):
         filename = filedialog.askopenfilename(filetypes=[("Video Files", "*.mp4 *.mkv *.mov *.avi"), ("All Files", "*.*")])
         if filename:
             self.clip_file_entry.delete(0, tk.END)
             self.clip_file_entry.insert(0, filename)
             self.source_var.set("file")

    def setup_bindings(self):
        # Bind tab change event
        self.notebook.bind("<<NotebookTabChanged>>", self.on_tab_changed)
        # Bind click for checkbox
        self.clip_tree.bind("<Button-1>", self.toggle_checkbox)

    def on_tab_changed(self, event):
        # Update button text based on tab
        mode = self.notebook.index(self.notebook.select())
        if mode == 2: # AI
            self.run_btn.config(text="Process (Generate Highlights)")
        elif mode == 3: # Clipper
            self.run_btn.config(text="Process (Clip Video)")
        else:
            self.run_btn.config(text="Extract Transcript")

    def toggle_checkbox(self, event):
        item = self.clip_tree.identify_row(event.y)
        column = self.clip_tree.identify_column(event.x)
        if item and column == '#1': # First column is select
            current_val = self.clip_tree.item(item, "values")[0]
            new_val = "☑" if current_val == "☐" else "☐"
            # Update only the checkbox, keep other values
            old_values = self.clip_tree.item(item, "values")
            self.clip_tree.item(item, values=(new_val, old_values[1], old_values[2], old_values[3]))

    def load_highlights_to_tree(self, filename):
        for i in self.clip_tree.get_children():
            self.clip_tree.delete(i)
            
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                data = json.load(f)
                
            if isinstance(data, list):
                for item in data:
                    # Insert with Checkbox as first value
                    self.clip_tree.insert("", tk.END, values=("☑", item.get('start'), item.get('end'), item.get('title')))
            else:
                messagebox.showerror("Error", "Invalid highlights JSON format (expected list)")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load JSON: {e}")

    def start_extraction(self):
        mode = self.notebook.index(self.notebook.select()) 
        
        # General inputs
        output_dir = self.out_dir_var.get()
        if not output_dir:
            messagebox.showerror("Error", "Please select an output directory")
            return
            
        # CLIPPER MODE (3)
        if mode == 3:
            hl_file = self.hl_json_entry.get()
            if not hl_file:
                messagebox.showerror("Error", "Please load a Highlights JSON file")
                return
            
            # Get selected items (checked ones)
            clips_to_process = []
            for item in self.clip_tree.get_children():
                vals = self.clip_tree.item(item)['values']
                if vals[0] == "☑":
                    clips_to_process.append({"start": vals[1], "end": vals[2], "title": vals[3]})
            
            if not clips_to_process:
                 messagebox.showerror("Error", "Please select at least one clip (checkbox)")
                 return
            
            source_type = self.source_var.get()
            source_url = self.clip_url_entry.get().strip()
            source_file = self.clip_file_entry.get().strip()
            
            if source_type == "url" and not source_url:
                messagebox.showerror("Error", "Please enter a YouTube URL")
                return
            if source_type == "file" and not source_file:
                messagebox.showerror("Error", "Please select a source video file")
                return
                
            self.run_btn.config(state='disabled')
            thread = threading.Thread(target=self.run_clipping_process, args=(clips_to_process, source_type, source_url, source_file, output_dir))
            thread.daemon = True
            thread.start()
            return


        url = self.url_entry.get().strip()
        filepath = self.file_entry.get().strip()
        jsonpath = self.json_entry.get().strip()
        model_size = self.model_var.get()
        force_dl = self.force_dl_var.get()


        if mode == 0 and not url:
            messagebox.showerror("Error", "Please enter a YouTube URL")
            return
        if mode == 1 and not filepath:
            messagebox.showerror("Error", "Please select a file")
            return
        if mode == 2 and not jsonpath:
             messagebox.showerror("Error", "Please select a JSON transcript file")
             return

        self.run_btn.config(state='disabled')
        
        # Run in separate thread to not freeze GUI
        thread = threading.Thread(target=self.run_process, args=(mode, url, filepath, jsonpath, output_dir, model_size, force_dl))
        thread.daemon = True
        thread.start()

    def run_clipping_process(self, clips, source_type, url, filepath, output_dir):
        try:
            video_path = None
            temp_download = False
            
            if source_type == "url":
                logging.info(f"Downloading source video from: {url}")
                video_path, title = download_video(url)
                temp_download = True
                logging.info(f"Video downloaded: {video_path}")
            else:
                video_path = filepath
                logging.info(f"Using local source video: {video_path}")
                
            if not video_path or not os.path.exists(video_path):
                raise FileNotFoundError("Source video not found")

            logging.info(f"Processing {len(clips)} clips...")
            
            success_count = 0
            for i, clip in enumerate(clips):
                start = float(clip['start'])
                end = float(clip['end'])
                title = clip['title']
                
                # Sanitize title
                safe_title = "".join(x for x in title if (x.isalnum() or x in "._- "))
                out_name = f"FINAL{i+1}_{safe_title}.mp4"
                out_path = os.path.join(output_dir, out_name)
                
                logging.info(f"Clipping: {title} ({start}s - {end}s)")
                if clip_video(video_path, start, end, out_path):
                    success_count += 1
                else:
                    logging.error(f"Failed to clip: {title}")
            
            logging.info(f"Clipping Complete. {success_count}/{len(clips)} successful.")
            messagebox.showinfo("Done", f"Created {success_count} clips in {output_dir}")

        except Exception as e:
            logging.error(f"Clipping Error: {e}")
            messagebox.showerror("Error", str(e))
        
        finally:
            # Cleanup temp video if downloaded
            if temp_download and video_path and os.path.exists(video_path):
                 try:
                     os.remove(video_path)
                     logging.info(f"Temporary video file removed: {video_path}")
                 except Exception as e:
                     logging.warning(f"Failed to remove temp video: {e}")
            
            self.root.after(0, lambda: self.run_btn.config(state='normal'))

    def run_process(self, mode, url, filepath, jsonpath, output_dir, model_size, force_dl):
        try:
            transcript_data = None
            output_name = "transcript"

            audio_path = None
            if mode == 0: # YouTube
                logging.info(f"Processing URL: {url}")
                # Logic copied from main.py simplified
                if not force_dl:
                    transcript_data = get_youtube_transcript(url)
                
                if not transcript_data:
                    if not force_dl:
                        logging.warning("No captions found, downloading audio...")
                    audio_path, title = download_audio(url)
                    logging.info(f"Downloaded: {title}")
                    transcript_data = transcribe_audio_file(audio_path, model_size=model_size)
                    output_name = title # Use video title
            
            elif mode == 1: # Local File
                logging.info(f"Processing File: {filepath}")
                transcript_data = transcribe_audio_file(filepath, model_size=model_size)
                output_name = os.path.splitext(os.path.basename(filepath))[0]
            
            elif mode == 2: # AI Highlights
                logging.info(f"Generating Highlights from: {jsonpath}")
                highlights = extract_highlights(jsonpath)
                
                # Save highlights directly
                base_name = os.path.splitext(os.path.basename(jsonpath))[0]
                out_name = f"{base_name}_highlights.json"
                out_path = os.path.join(output_dir, out_name)
                
                with open(out_path, 'w', encoding='utf-8') as f:
                    json.dump(highlights, f, indent=4, ensure_ascii=False)
                    
                logging.info("DONE! Highlights generated.")
                messagebox.showinfo("Success", f"Highlights saved to\n{out_path}")
                return # Exit early since we handled saving

            if transcript_data:
                # Sanitize filename
                safe_name = "".join(x for x in output_name if (x.isalnum() or x in "._- "))
                out_path = os.path.join(output_dir, f"{safe_name}.json")
                save_transcript(transcript_data, out_path)
                logging.info("DONE! Transcript saved.")
                messagebox.showinfo("Success", f"Transcript saved to\n{out_path}")
            else:
                logging.error("Failed to extract transcript.")
                messagebox.showerror("Error", "Failed to extract transcript.")

        except Exception as e:
            logging.error(f"Error: {e}")
            messagebox.showerror("Error", str(e))
        finally:
            # Cleanup temp audio from download
            if audio_path and os.path.exists(audio_path):
                 try:
                     os.remove(audio_path)
                     logging.info(f"Temporary audio file removed: {audio_path}")
                 except Exception as e:
                     logging.warning(f"Failed to remove temp file: {e}")
            
            self.root.after(0, lambda: self.run_btn.config(state='normal'))

def launch_gui():
    root = tk.Tk()
    app = TranscriptApp(root)
    root.mainloop()
