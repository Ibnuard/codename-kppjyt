import hmac
import hashlib
import os
import json
import base64
import sys
import shutil
from datetime import datetime, timedelta

SECRET_KEY = b"Klipah-Global-Secret-Key-2026"
LOCAL_SECRET = b"Klipah-Local-Secret-State"

def get_hmac(data: str, secret: bytes) -> str:
    return hmac.new(secret, data.encode('utf-8'), hashlib.sha256).hexdigest()[:12].upper()

def activate_token(b64_token: str, app_root: str):
    """
    Decodes the token, checks the validity deadline, and generates a local license state.
    """
    try:
        token_str = base64.b64decode(b64_token.strip()).decode('utf-8')
        if token_str.count('-') != 2:
            return False, "Invalid token format."
            
        validity, duration, signature = token_str.split("-")
        
        # Verify Token Signature
        expected_sig = get_hmac(f"{validity}-{duration}", SECRET_KEY)
        if signature.upper() != expected_sig:
            return False, "Tampered or forged token."
            
        # Check Validity Deadline
        validity_date = datetime.strptime(validity, "%Y%m%d")
        now = datetime.now()
        
        # We only care that the token is ACTIVATED before its validity deadline
        # Allowing them to activate on the exact day.
        # So we compare just dates.
        if now.date() > validity_date.date():
            return False, f"This token expired for activation on {validity_date.strftime('%Y-%m-%d')}."
            
        # Calculate Expiration Date
        dur_map = {
            "TRIAL": 1,
            "1M": 30,
            "3M": 90,
            "6M": 180,
            "LF": 36500
        }
        
        if duration not in dur_map:
            return False, "Invalid token duration embedded."
            
        days_to_add = dur_map[duration]
        expiration_date = now + timedelta(days=days_to_add)
        
        # Build local state
        activation_iso = now.isoformat()
        expiration_iso = expiration_date.isoformat()
        
        local_sig = get_hmac(f"{activation_iso}-{expiration_iso}", LOCAL_SECRET)
        
        state = {
            "token": b64_token,
            "activation_date": activation_iso,
            "expiration_date": expiration_iso,
            "local_signature": local_sig
        }
        
        # Write to JSON
        license_path = os.path.join(app_root, "license.json")
        with open(license_path, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=4)
            
        return True, f"Activated successfully! Valid until {expiration_date.strftime('%Y-%m-%d %H:%M:%S')}"
    except Exception as e:
        return False, f"Error activating token: {str(e)}"

def verify_license(app_root: str):
    """
    Reads the local license.json, validates integrity, and checks if absolute expiration has passed.
    """
    license_path = os.path.join(app_root, "license.json")
    
    # Fallback to old license.txt check (Legacy) for users who haven't updated their token
    legacy_path = os.path.join(app_root, "license.txt")
    if os.path.exists(legacy_path) and not os.path.exists(license_path):
        try:
            with open(legacy_path, "r", encoding="utf-8-sig") as f:
                key = ''.join(c for c in f.read().strip() if c.isalnum() or c == '-')
            if "-" in key:
                expiry_str, signature = key.split("-")
                expected_sig = get_hmac(expiry_str, SECRET_KEY)
                if signature.upper() == expected_sig:
                    if datetime.now() < datetime.strptime(expiry_str, "%Y%m%d"):
                        return True, "Active (Legacy)"
        except:
            pass
            
    if not os.path.exists(license_path):
        return False, "MISSING_LICENSE"
        
    try:
        with open(license_path, "r", encoding="utf-8") as f:
            state = json.load(f)
            
        activation_iso = state.get("activation_date", "")
        expiration_iso = state.get("expiration_date", "")
        local_signature = state.get("local_signature", "")
        
        # Check tamper signature
        expected_sig = get_hmac(f"{activation_iso}-{expiration_iso}", LOCAL_SECRET)
        if local_signature != expected_sig:
            return False, "TAMPERED_STATE"
            
        # Check actual expiration
        exp_date = datetime.fromisoformat(expiration_iso)
        if datetime.now() > exp_date:
            return False, "EXPIRED"
            
        return True, "Active"
    except Exception as e:
        return False, "CORRUPTED"
        
def trigger_self_destruct(app_root: str):
    """
    Deletes the core backend logic files to lock the app permanently.
    """
    files_to_delete = [
        os.path.join(app_root, "app", "server.py"),
        os.path.join(app_root, "app", "src", "video_clipper.py"),
        os.path.join(app_root, "app", "src", "highlight_extractor.py")
    ]
    
    for f in files_to_delete:
        try:
            if os.path.exists(f):
                os.remove(f)
        except:
            pass
