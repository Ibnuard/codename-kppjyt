import cv2
import os
import logging
# from gtts import gTTS  <-- Removed
from dotenv import load_dotenv
from elevenlabs.client import ElevenLabs
from PIL import Image, ImageDraw, ImageFont, ImageEnhance
import subprocess
import numpy as np
import textwrap

# Load env vars
load_dotenv()

def generate_intro(video_path, title, output_path, elevenlabs_api_key=None):
    """
    Generate creator-style intro video:
    - Ambil frame 20% dari video
    - Dark overlay + gradient cinematic
    - Text creator style (outline + glow)
    - TTS suara Indonesia (Now using ElevenLabs)
    - Render mp4 via ffmpeg
    """

    # Init ElevenLabs inside function to use provided API key
    kb_key = elevenlabs_api_key
    if not kb_key:
        logging.error("ElevenLabs API Key missing. Skipping intro generation.")
        return False

    client = ElevenLabs(api_key=kb_key)

    try:
        logging.info(f"Generating intro for: {title}")

        temp_dir = os.path.dirname(output_path)
        img_path = os.path.join(temp_dir, "temp_intro_frame.jpg")
        audio_path = os.path.join(temp_dir, "temp_intro_audio.mp3")

        # ==========================
        # 1) EXTRACT FRAME
        # ==========================
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            raise RuntimeError("Could not open video")

        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        target_frame = int(total_frames * 0.2)   # hindari fade-in
        cap.set(cv2.CAP_PROP_POS_FRAMES, target_frame)
        ret, frame = cap.read()
        cap.release()

        if not ret or frame is None:
            raise RuntimeError("Could not read frame")

        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        pil_image = Image.fromarray(frame_rgb)

        # ==========================
        # 2) DARKEN + GRADIENT
        # ==========================
        enhancer = ImageEnhance.Brightness(pil_image)
        pil_image = enhancer.enhance(0.45)  # dasar agak gelap

        W, H = pil_image.size

        # Gradient overlay (lebih cinematic)
        overlay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        draw_overlay = ImageDraw.Draw(overlay)

        for y in range(H):
            alpha = int(140 * (y / H))  # makin bawah makin gelap
            draw_overlay.line([(0, y), (W, y)], fill=(0, 0, 0, alpha))

        pil_image = Image.alpha_composite(
            pil_image.convert("RGBA"), overlay
        ).convert("RGB")

        draw = ImageDraw.Draw(pil_image)

        # ==========================
        # 3) FONT SETUP (CREATOR STYLE)
        # ==========================
        font_size = int(W * 0.085)  # responsif

        possible_fonts = [
            "C:\\Windows\\Fonts\\impact.ttf",      # TikTok / Shorts feel
            "C:\\Windows\\Fonts\\arialbd.ttf",     # fallback bold
            "arial.ttf"
        ]

        font = None
        for f in possible_fonts:
            if os.path.exists(f):
                font = ImageFont.truetype(f, font_size)
                break

        if font is None:
            logging.warning("Using default font (may look small)")
            font = ImageFont.load_default()

        # ==========================
        # 4) TEXT WRAPPING
        # ==========================
        avg_char_width = font_size * 0.55
        chars_per_line = int((W * 0.8) / avg_char_width)
        lines = textwrap.wrap(title, width=chars_per_line)

        # Hitung tinggi total teks
        text_height = 0
        line_heights = []

        for line in lines:
            bbox = draw.textbbox((0, 0), line, font=font)
            h = bbox[3] - bbox[1]
            line_heights.append(h)
            text_height += h + 14

        current_y = (H - text_height) / 2

        # ==========================
        # 5) CREATOR TEXT FUNCTION
        # ==========================
        outline_width = max(2, int(font_size * 0.07))
        glow_radius = max(3, int(font_size * 0.1))

        def draw_creator_text(draw, x, y, text, font):
            # Glow (soft shadow)
            for dx in range(-glow_radius, glow_radius + 1, 2):
                for dy in range(-glow_radius, glow_radius + 1, 2):
                    draw.text(
                        (x + dx, y + dy),
                        text,
                        font=font,
                        fill=(0, 0, 0, 80)
                    )

            # Outline hitam
            for dx in range(-outline_width, outline_width + 1):
                for dy in range(-outline_width, outline_width + 1):
                    draw.text(
                        (x + dx, y + dy),
                        text,
                        font=font,
                        fill=(0, 0, 0)
                    )

            # Main text (kuning khas creator)
            draw.text(
                (x, y),
                text,
                font=font,
                fill=(255, 225, 60)  # kuning hangat
            )

        # ==========================
        # 6) DRAW TEXT CENTER
        # ==========================
        for i, line in enumerate(lines):
            bbox = draw.textbbox((0, 0), line, font=font)
            w = bbox[2] - bbox[0]
            x = (W - w) / 2

            draw_creator_text(draw, x, current_y, line, font)
            current_y += line_heights[i] + 14

        pil_image.save(img_path)

        # ==========================
        # 7) TTS AUDIO (ELEVENLABS)
        # ==========================
        # tts = gTTS(text=title, lang="id", slow=False)
        # tts.save(audio_path)
        
        logging.info("Generating TTS with ElevenLabs...")
        try:
            audio_generator = client.text_to_speech.convert(
                text=title,
                voice_id="Fk9kKdjJ4c7T6junqCwK",  # User specified voice ID
                model_id="eleven_multilingual_v2",
                output_format="mp3_44100_128",
            )
            
            # Save the generator output to file
            with open(audio_path, 'wb') as f:
                for chunk in audio_generator:
                    f.write(chunk)
                    
        except Exception as tts_err:
            logging.error(f"ElevenLabs TTS failed: {tts_err}")
            # Fallback or re-raise? 
            # For now re-raise to see error in log
            raise tts_err


        # ==========================
        # 8) RENDER VIDEO WITH FFMPEG
        # ==========================
        cmd = [
            "ffmpeg", "-y",
            "-loop", "1",
            "-i", img_path,
            "-i", audio_path,

            # ===== AUDIO STYLING (NATURAL) =====
            "-af",
            "loudnorm=I=-14:TP=-1.5:LRA=11",        # Normalize volume only

            "-c:v", "libx264",
            "-tune", "stillimage",
            "-pix_fmt", "yuv420p",
            "-c:a", "aac",
            "-b:a", "192k",
            "-shortest",
            output_path
        ]

        subprocess.run(
            cmd,
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

        # Cleanup
        try:
            os.remove(img_path)
            os.remove(audio_path)
        except:
            pass

        logging.info(f"Intro selesai: {output_path}")
        return True

    except Exception as e:
        logging.error(f"Intro failed: {e}")
        return False
