"""
AI-powered transcription refinement using the same API pattern as highlight_extractor.py.
Supports both Google Gemini (Direct) and OpenRouter.
Implements chunking strategy for Gemini free tier token limits.
"""
import json
import logging
import requests
import os
import time
from dotenv import load_dotenv

load_dotenv()

# =====================================================
# SHARED API LOADERS (Same as highlight_extractor.py)
# =====================================================

def load_api_key():
    """Load OpenRouter API Key from env."""
    try:
        return os.environ.get("OPEN_ROUTER_API_KEY")
    except Exception as e:
        logging.error(f"Error loading API Key: {e}")
    return None


def load_gemini_api_key():
    """Load Gemini API Key from env."""
    try:
        return os.environ.get("GEMINI_API_KEY")
    except Exception as e:
        logging.error(f"Error loading Gemini API Key: {e}")
    return None


# =====================================================
# CHUNKING CONFIGURATION
# =====================================================

# Gemini Free Tier limits: ~32k tokens input, ~8k output
# Conservative chunk sizes to avoid hitting limits
CHUNK_SIZE_SEGMENTS = 10        # Max segments per chunk
MAX_CHARS_PER_CHUNK = 3000     # Max characters per chunk (~750 tokens)
REQUEST_DELAY_SECONDS = 0.8    # Delay between API calls to respect rate limits


def estimate_tokens(text):
    """Rough token estimation (1 token ≈ 4 chars for Indonesian)."""
    return len(text) // 4


def split_segments_into_chunks(segments, max_segments=CHUNK_SIZE_SEGMENTS, max_chars=MAX_CHARS_PER_CHUNK):
    """
    Split segments into chunks that respect both segment count and character limits.
    Returns list of (start_index, segments_chunk) tuples.
    """
    chunks = []
    current_chunk = []
    current_chars = 0
    chunk_start_idx = 0
    
    for i, seg in enumerate(segments):
        seg_text = seg.get('text', '')
        seg_chars = len(seg_text)
        
        # Check if adding this segment would exceed limits
        would_exceed_segments = len(current_chunk) >= max_segments
        would_exceed_chars = (current_chars + seg_chars) > max_chars and len(current_chunk) > 0
        
        if would_exceed_segments or would_exceed_chars:
            # Save current chunk and start new one
            if current_chunk:
                chunks.append((chunk_start_idx, current_chunk))
            current_chunk = [seg]
            current_chars = seg_chars
            chunk_start_idx = i
        else:
            current_chunk.append(seg)
            current_chars += seg_chars
    
    # Don't forget the last chunk
    if current_chunk:
        chunks.append((chunk_start_idx, current_chunk))
    
    return chunks


def call_refine_api(prompt, model, api_key, is_gemini_direct, timeout=60):
    """
    Make API call for refinement using the same pattern as highlight_extractor.py.
    Returns parsed JSON or None on failure.
    """
    # Strip prefix for direct Gemini calls
    api_model = model.replace("google/", "") if is_gemini_direct else model
    
    try:
        if is_gemini_direct:
            # --- GOOGLE GEMINI DIRECT ---
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{api_model}:generateContent"
            headers = {
                "Content-Type": "application/json",
                "x-goog-api-key": api_key
            }
            payload = {
                "contents": [{"parts": [{"text": prompt}]}],
                "generationConfig": {
                    "temperature": 0.3,  # Lower temp for more consistent refinement
                    "maxOutputTokens": 2048
                }
            }
        else:
            # --- OPENROUTER ---
            url = "https://openrouter.ai/api/v1/chat/completions"
            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "HTTP-Referer": "http://localhost:8000",
                "X-Title": "TranscriptRefiner",
            }
            payload = {
                "model": api_model,
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.3,
            }
        
        response = requests.post(url, headers=headers, json=payload, timeout=timeout)
        
        if response.status_code == 429:
            # Rate limited - wait and return None to trigger retry
            logging.warning(f"Rate limited (429). Will retry after delay.")
            return None
            
        if response.status_code != 200:
            logging.error(f"API Error {response.status_code}: {response.text[:500]}")
            return None
        
        result = response.json()
        
        # Extract content based on API type
        if is_gemini_direct:
            try:
                content = result['candidates'][0]['content']['parts'][0]['text']
            except (KeyError, IndexError) as e:
                logging.error(f"Unexpected Gemini response structure: {e}")
                return None
        else:
            try:
                # OpenRouter / Z.AI
                message = result['choices'][0]['message']
                content = message.get('content', '')
                
                # Fallback for models (like Z.AI GLM) that output to reasoning
                if not content and message.get('reasoning'):
                     logging.warning("Content empty, using 'reasoning' field.")
                     content = message['reasoning']
                     
            except (KeyError, IndexError) as e:
                logging.error(f"Unexpected OpenRouter response structure: {e}")
                return None
        
        # Clean up markdown formatting
        content = content.strip()
        if content.startswith("```json"):
            content = content[7:]
        if content.startswith("```"):
            content = content[3:]
        if content.endswith("```"):
            content = content[:-3]
        content = content.strip()
        
        # Parse JSON
        try:
            return json.loads(content)
        except json.JSONDecodeError as e:
            logging.error(f"JSON parse error: {e}. Content: {content[:200]}...")
            return None
            
    except requests.exceptions.Timeout:
        logging.error(f"API request timed out after {timeout}s")
        return None
    except Exception as e:
        logging.error(f"API call failed: {e}")
        return None


def refine_transcription(transcript_data, model="google/gemini-3-flash-preview"):
    """
    Refine transcription using AI.
    Inputs: Short clip transcript (< 60s).
    Strategy: 
      1. Try Primary Model (Gemini 3 Flash).
      2. If fails, Retry with Fallback (Z.AI GLM 4.5 Air).
    """
    if not transcript_data or not transcript_data.get('segments'):
        logging.warning("No segments to refine")
        return transcript_data
    
    segments = transcript_data['segments']
    
    # helper to run refinement loop
    def attempt_refinement(use_model):
        logging.info(f"Refining {len(segments)} segments with model: {use_model}")
        
        is_gemini_direct = "gemini" in use_model.lower() and use_model.startswith("google/")
        
        if is_gemini_direct:
            api_key = load_gemini_api_key()
            if not api_key:
                logging.error("GEMINI_API_KEY missing.")
                return None
        else:
            api_key = load_api_key()
            if not api_key:
                logging.error("OPEN_ROUTER_API_KEY missing.")
                return None
        
        # Build prompt
        chunk_lines = []
        for i, seg in enumerate(segments):
            text = seg.get('text', '').strip()
            chunk_lines.append(f"[{i}] {text}")
        
        full_text = "\n".join(chunk_lines)
    
        prompt = (
            "Kamu adalah editor transkrip profesional untuk bahasa Indonesia.\n"
            "Tugas: Perbaiki typo, ejaan, dan kata yang salah dengar (misheard words) agar natural untuk subtitle sosmed.\n"
            "Input ini adalah satu klip pendek utuh (< 60 detik).\n\n"
            "ATURAN KETAT:\n"
            "1. JANGAN ubah makna atau maksud kalimat\n"
            "2. JANGAN hapus atau tambah kalimat baru (jumlah baris harus SAMA PERSIS)\n"
            "3. Output HANYA JSON Array of strings, urut sesuai input.\n"
            f"INPUT ({len(segments)} item):\n{full_text}\n\n"
            "OUTPUT (JSON array):"
        )
    
        max_retries = 1
        for attempt in range(max_retries + 1):
            refined_output = call_refine_api(prompt, use_model, api_key, is_gemini_direct)
            
            if refined_output is not None:
                if isinstance(refined_output, list) and len(refined_output) == len(segments):
                    return refined_output
                else:
                    logging.warning(f"Invalid format/length from {use_model}. Retry {attempt+1}")
            
            if attempt < max_retries:
                time.sleep(2)
                
        return None

    # 1. Try Primary
    refined_result = attempt_refinement(model)
    
    # 2. Try Fallback if Primary failed
    if not refined_result:
        fallback_model = "z-ai/glm-4.5-air:free"
        if model != fallback_model:
            logging.warning(f"Primary model {model} failed. Switching to fallback: {fallback_model}")
            refined_result = attempt_refinement(fallback_model)

    # Apply changes if success
    if refined_result:
        update_count = 0
        for i, refined_text in enumerate(refined_result):
            new_text = str(refined_text).strip()
            if segments[i]['text'] != new_text:
                segments[i]['text'] = new_text
                update_count += 1
                
                if 'words' in segments[i]:
                    old_words = segments[i]['words']
                    new_word_list = new_text.split()
                    
                    if len(new_word_list) == len(old_words):
                        for j, w in enumerate(old_words):
                            w['word'] = new_word_list[j]
                    else:
                         del segments[i]['words']

        logging.info(f"Refinement success. Updated {update_count}/{len(segments)} segments.")
    else:
        logging.warning("All refinement attempts failed. Keeping original text.")

    # Update full text
    transcript_data['text'] = " ".join([s.get('text', '') for s in segments])
    return transcript_data
