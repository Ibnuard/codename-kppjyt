import subprocess
import logging
import os
from .utils import check_ffmpeg, get_font_path, get_src_dir
from .face_cropper import dynamic_face_crop_9x16

def burn_subtitles(input_path, audio_source_path, srt_path, output_path, 
                   channel_name=None, logo_path=None, watermark_position="none"):
    """
    Burn subtitles into a video using FFmpeg and merge audio from audio_source_path.
    Adds creator credit watermark based on position.
    
    Args:
        input_path: Path to input video
        audio_source_path: Path to audio source
        srt_path: Path to SRT subtitle file
        output_path: Path to output video
        channel_name: Optional channel name for credit overlay (e.g., "@channelname")
        logo_path: Optional path to channel logo/avatar image
        watermark_position: 'none', 'center', 'top_left', 'top_right'
    """
    if not check_ffmpeg():
        return False
        
    from .subtitler import get_burn_subtitles_filter
    
    # Get the YouTube logo fallback path
    youtube_logo = os.path.join(get_src_dir(), "youtube.png")
    
    # Build FFmpeg command
    cmd = ["ffmpeg", "-y"]
    
    # Inputs: only video + audio
    cmd.extend(["-i", input_path])       # 0: video
    cmd.extend(["-i", audio_source_path]) # 1: audio
    
    # Build filter chain
    subtitle_filter = get_burn_subtitles_filter(srt_path)

    if watermark_position != "none" and channel_name:
        # Escape special chars for FFmpeg drawtext
        safe_channel = channel_name.replace("'", "'\\''" ).replace(":", "\\:")
        actual_logo = logo_path if logo_path and os.path.exists(logo_path) else youtube_logo
        
        # Determine coordinates based on position
        if watermark_position == "top_left":
            img_x, img_y = "40", "50"
            tx, ty = "120", "50"  # Logo is ~64w + gap
        elif watermark_position == "center": 
            # Center: stack vertically (logo on top, text below)
            # NOTE: text_w/text_h are only available in drawtext, NOT in overlay.
            # So overlay uses simple centering, drawtext uses its own text_w.
            img_x, img_y = "(W-64)/2", "(H/2)-50"         # Logo centered, slightly above mid
            tx, ty = "(w-text_w)/2", "(h/2)+30"            # Text centered, below logo
        else:
            # Fallback: default to center (same as above)
            img_x, img_y = "(W-64)/2", "(H/2)-50"
            tx, ty = "(w-text_w)/2", "(h/2)+30"

        # Use centralized font path (handles frozen apps + existence check)
        escaped_font_path = get_font_path(escaped=True)

        filter_chain = (
            f"[2:v]scale=-1:64[logo];"
            f"[0:v][logo]overlay=x={img_x}:y={img_y}[v_logo];"
            f"[v_logo]{subtitle_filter},"
            f"drawtext=text='{safe_channel}':"
            f"fontfile='{escaped_font_path}':"
            f"fontsize=64:"
            f"fontcolor=white@0.7:"
            f"x={tx}:"
            f"y={ty}:"
            f"shadowcolor=black@0.5:shadowx=3:shadowy=3[outv]"
        )
        cmd.extend(["-i", actual_logo])
        cmd.extend(["-filter_complex", filter_chain])
        cmd.extend(["-map", "[outv]", "-map", "1:a"])
    else:
        # No credit or position is 'none', just subtitles
        cmd.extend(["-vf", subtitle_filter])
        cmd.extend(["-map", "0:v", "-map", "1:a"])
    cmd.extend(["-c:v", "libx264", "-preset", "veryfast", "-crf", "23"])
    cmd.extend(["-c:a", "aac", "-b:a", "192k"])
    cmd.extend(["-shortest", output_path])
    
    logging.info(f"Merging Video with subtitles and credits -> {output_path}")
    logging.info(f"FFmpeg CMD: {' '.join(cmd)}")
    process = subprocess.run(cmd, capture_output=True, text=True)
    
    # Always log stderr for debugging
    if process.stderr:
        # Only log last 500 chars to avoid flooding
        stderr_tail = process.stderr[-500:] if len(process.stderr) > 500 else process.stderr
        logging.info(f"FFmpeg stderr (tail): {stderr_tail}")
    
    if process.returncode != 0:
        logging.error(f"FFmpeg Burn Error: {process.stderr}")
        return False
        
    return True

def get_focal_point(video_path):
    """
    Use MediaPipe Tasks API to find the average horizontal focal point (face/person) 
    by sampling a few frames. Returns a normalized X coordinate (0.0 to 1.0).
    """
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        return 0.5 # Default to center
        
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    sample_points = [0.1, 0.3, 0.5, 0.7, 0.9]
    x_coords = []
    
    for p in sample_points:
        frame_idx = int(total_frames * p)
        cap.set(cv2.CAP_PROP_POS_FRAMES, frame_idx)
        ret, frame = cap.read()
        if not ret:
            continue
            
        # Convert to RGB (MediaPipe expects RGB)
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # Load the input image from a numpy array
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb_frame)
        
        # Detect faces in the input image
        detection_result = face_detector.detect(mp_image)
        
        if detection_result.detections:
            # Get center of the first detection
            for detection in detection_result.detections:
                bbox = detection.bounding_box
                # MediaPipe Tasks bounding box is in pixels
                height, width, _ = frame.shape
                center_x = (bbox.origin_x + (bbox.width / 2)) / width
                x_coords.append(center_x)
                break
                
    cap.release()
    
    if not x_coords:
        return 0.5 # fallback to center
        
    return float(np.mean(x_coords))

def clip_video(source_path, start_time, end_time, output_path, crop_9x16=False, srt_path=None):
    """
    Clip a video file from start_time to end_time using FFmpeg.
    Optional: crop to 9:16 vertical and burn subtitles.
    """
    if not check_ffmpeg():
        logging.error("FFmpeg not found. Cannot clip video.")
        return False

    try:
        duration = end_time - start_time
        if duration <= 0:
            logging.error(f"Invalid duration: {duration}")
            return False

        # Input seeking for speed
        filters = []
        
        if crop_9x16:
            # 1. Get focal point
            focal_x_norm = get_focal_point(source_path)
            
            # 2. Construct Crop Filter
            # Target aspect ratio 9:16
            # We assume input is horizontal (e.g. 1920x1080)
            # Crop width = ih * (9/16)
            # Crop height = ih
            # X position = (iw * focal_x) - (crop_w / 2)
            # But must stay within bounds [0, iw - crop_w]
            
            # wrap the entire crop filter value in quotes to handle commas, 
            # or escape the commas inside clip()
            crop_filter = (
                f"crop=ih*9/16:ih:"
                f"clip(iw*{focal_x_norm}-ih*9/32\\,0\\,iw-ih*9/16):0"
            )
            filters.append(crop_filter)
            
        if srt_path:
            from .subtitler import get_burn_subtitles_filter
            filters.append(get_burn_subtitles_filter(srt_path))

        cmd = [
            "ffmpeg", "-y",
            "-ss", str(start_time),
            "-i", source_path,
            "-t", str(duration)
        ]
        
        if filters:
            cmd.extend(["-vf", ",".join(filters)])
            # Re-encoding is required when using filters
            cmd.extend(["-c:v", "libx264", "-preset", "veryfast", "-c:a", "aac"])
        else:
            # If no filters, try fast seeking + copy if possible, 
            # but usually re-encoding is safer for accurate cuts.
            cmd.extend(["-c:v", "libx264", "-c:a", "aac"])

        cmd.append(output_path)
        
        logging.info(f"Running FFmpeg: {' '.join(cmd)}")
        process = subprocess.run(cmd, capture_output=True, text=True)
        
        if process.returncode != 0:
            logging.error(f"FFmpeg Error: {process.stderr}")
            return False
            
        logging.info(f"Clip saved to: {output_path}")
        return True

    except Exception as e:
        logging.error(f"Error cutting video: {e}")
        return False

def concatenate_videos_with_transition(video_paths, output_path, transition_path, sfx_path):
    """
    Concatenate Intro (video_paths[0]) and Main (video_paths[1]) with a greenscreen 
    transition overlay and SFX mixing at the junction point.
    """
    if not check_ffmpeg():
        return False
        
    if len(video_paths) < 2:
        return concatenate_videos(video_paths, output_path)
        
    try:
        # 1. Get duration of the first video (Intro) for timing
        cmd_dur = [
            "ffprobe", "-v", "error", "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1", video_paths[0]
        ]
        intro_duration = float(subprocess.check_output(cmd_dur).decode().strip())
        
        # 2. Get transition duration
        cmd_tr_dur = [
            "ffprobe", "-v", "error", "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1", transition_path
        ]
        trans_duration = float(subprocess.check_output(cmd_tr_dur).decode().strip())
        
        # Calculate overlay start time (centered at junction)
        overlay_start = intro_duration - (trans_duration / 2.0)
        sfx_delay = int(overlay_start * 1000) # delay in ms
        if sfx_delay < 0: sfx_delay = 0

        # Construct filter complex
        # [0:v] Intro [1:v] Main [2:v] Transition
        # [0:a] Intro [1:a] Main [3:a] SFX
        
        # Normalize all inputs to 1080x1920 (Vertical) and 30fps
        filter_parts = []
        for i, path in enumerate(video_paths):
            filter_parts.append(
                f"[{i}:v]fps=30,scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2,setsar=1[v{i}]"
            )
            filter_parts.append(
                f"[{i}:a]aformat=sample_rates=44100:channel_layouts=stereo[a{i}]"
            )
        
        # Concat Intro + Main (Base)
        filter_parts.append(f"[v0][a0][v1][a1]concat=n=2:v=1:a=1[basev][basea]")
        
        # Process Transition Video (Greenscreen)
        # Apply chromakey and force scaling to ensure it matches base
        # format=yuva420p is often more compatible for transparency overlay
        # setpts=PTS-STARTPTS+X/TB is CRITICAL to shift the transition timestamps to the junction point
        filter_parts.append(
            f"[2:v]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1,"
            f"chromakey=0x00FF00:0.15:0.2,format=yuva420p,"
            f"setpts=PTS-STARTPTS+{overlay_start}/TB[keyed_delayed]"
        )
        
        # Overlay Transition on Base
        # eof_action=pass ensures base video continues after overlay ends
        filter_parts.append(
            f"[basev][keyed_delayed]overlay=enable='between(t,{overlay_start},{overlay_start + trans_duration})':eof_action=pass[outv]"
        )
        
        # Process SFX Audio
        # Delay and Mix
        filter_parts.append(
            f"[3:a]adelay={sfx_delay}|{sfx_delay}[delayed_sfx]"
        )
        filter_parts.append(
            f"[basea][delayed_sfx]amix=inputs=2:duration=first[outa]"
        )
        
        full_filter = ";".join(filter_parts)
        
        cmd = [
            "ffmpeg", "-y",
            "-i", video_paths[0],  # 0
            "-i", video_paths[1],  # 1
            "-i", transition_path, # 2
            "-i", sfx_path,        # 3
            "-filter_complex", full_filter,
            "-map", "[outv]",
            "-map", "[outa]",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
            "-c:a", "aac", "-b:a", "192k",
            output_path
        ]
        
        logging.info(f"Concatenating with greenscreen transition: {video_paths} -> {output_path}")
        process = subprocess.run(cmd, capture_output=True, text=True)
        
        if process.returncode != 0:
            logging.error(f"FFmpeg Transition Concat Error: {process.stderr}")
            # Fallback to simple concat if transition fails
            return concatenate_videos(video_paths, output_path)
            
        return True
        
    except Exception as e:
        logging.error(f"Error in transition concatenation: {e}")
        return False

def concatenate_videos(video_paths, output_path):
    """
    Concatenate multiple video files using FFmpeg's filter_complex.
    Re-encodes to ensure compatibility between different sources (e.g. static intro vs variable fps clip).
    """
    if not check_ffmpeg():
        return False
        
    if not video_paths:
        return False
        
    try:
        # Construct filter complex command
        # ffmpeg -i v1 -i v2 -filter_complex "[0:v][0:a][1:v][1:a]concat=n=2:v=1:a=1[v][a]" -map [v] -map [a] ...
        
        cmd = ["ffmpeg", "-y"]
        filter_parts = []
        
        for i, path in enumerate(video_paths):
            cmd.extend(["-i", path])
            # Ensure compatible streams: set pts, fps, scale, sar
            # We force 30fps and 1080x1920 to match FaceCropper target
            filter_parts.append(f"[{i}:v]fps=30,scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2,setsar=1[v{i}];[{i}:a]aformat=sample_rates=44100:channel_layouts=stereo[a{i}]")
            
        concat_part = ""
        for i in range(len(video_paths)):
            concat_part += f"[v{i}][a{i}]"
        concat_part += f"concat=n={len(video_paths)}:v=1:a=1[outv][outa]"
        
        full_filter = ";".join(filter_parts) + ";" + concat_part
        
        cmd.extend([
            "-filter_complex", full_filter,
            "-map", "[outv]",
            "-map", "[outa]",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
            "-c:a", "aac", "-b:a", "192k",
            output_path
        ])
        
        logging.info(f"Concatenating videos (Re-encode): {video_paths} -> {output_path}")
        process = subprocess.run(cmd, capture_output=True, text=True)
        
        if process.returncode != 0:
            logging.error(f"FFmpeg Concat Error: {process.stderr}")
            return False
            
        return True
        
    except Exception as e:
        logging.error(f"Error concatenating videos: {e}")
        return False
