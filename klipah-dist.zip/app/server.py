from fastapi import FastAPI, HTTPException, Body, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import os
import shutil
import logging
import threading
import queue
from typing import List, Optional

# Import our existing modules
from src.youtube_extractor import download_video, get_youtube_transcript, download_audio, get_channel_info
from src.audio_transcriber import transcribe_audio_file
from src.highlight_extractor import extract_highlights, test_connection, list_gemini_models
from src.video_clipper import clip_video
from src.main import save_transcript
from src.utils import check_ffmpeg

# ...



import json
import logging
import time

# --- LOGGING ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# Note: In production, app_root is the parent of 'app' folder where 'license.txt' sits
APP_ROOT = os.path.dirname(BASE_DIR)

# --- LICENSE CHECK ---
from src.license_utils import check_license_file
import sys

is_valid, msg = check_license_file(APP_ROOT)
if not is_valid:
    logging.error(f"LICENSE ERROR: {msg}")
    print("\n" + "="*40)
    print(f" ERROR: {msg}")
    print(" Please contact support for a valid license key.")
    print("="*40 + "\n")
    time.sleep(5)
    sys.exit(1)
else:
    logging.info(f"License Verified: {msg}")
# ---------------------

# Check FFmpeg availability at startup
check_ffmpeg()

# --- CONFIGURATION & VERSION ---
VERSION_PATH = os.path.join(APP_ROOT, "version.txt")
CONFIG_PATH = os.path.join(APP_ROOT, "config.json")

def get_version():
    try:
        if os.path.exists(VERSION_PATH):
            with open(VERSION_PATH, "r") as f:
                return f.read().strip()
    except: pass
    return "1.0.0"

def get_default_projects_dir():
    # Cross-platform Desktop path
    home = os.path.expanduser("~")
    desktop_path = os.path.join(home, "Desktop", "KLIPAH_OUTPUT")
    return desktop_path

def load_config():
    default_config = {"projects_dir": get_default_projects_dir()}
    try:
        if os.path.exists(CONFIG_PATH):
            with open(CONFIG_PATH, "r") as f:
                config = json.load(f)
                # Ensure all keys exist
                for k, v in default_config.items():
                    if k not in config: config[k] = v
                return config
    except: 
        logging.error("Failed to load config.json, using defaults.")
    return default_config

def save_config(config):
    try:
        with open(CONFIG_PATH, "w") as f:
            json.dump(config, f, indent=4)
        return True
    except Exception as e:
        logging.error(f"Failed to save config: {e}")
        return False

# Initialize Configuration
CURRENT_CONFIG = load_config()
PROJECTS_DIR = CURRENT_CONFIG["projects_dir"]

if not os.path.exists(PROJECTS_DIR):
    try:
        os.makedirs(PROJECTS_DIR, exist_ok=True)
        logging.info(f"Created projects directory: {PROJECTS_DIR}")
    except Exception as e:
        logging.error(f"Could not create projects dir {PROJECTS_DIR}: {e}")
        # Fallback to local 'projects' if desktop fails
        PROJECTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "projects")

# -------------------------------

app = FastAPI()

# --- SETTINGS ENDPOINTS ---
@app.get("/version")
async def get_app_version():
    return {"version": get_version()}

@app.get("/settings")
async def get_settings():
    return load_config()

@app.post("/settings")
async def update_settings(config: dict):
    global PROJECTS_DIR
    success = save_config(config)
    if success:
        PROJECTS_DIR = config.get("projects_dir", PROJECTS_DIR)
        os.makedirs(PROJECTS_DIR, exist_ok=True)
        return {"success": True, "message": "Settings saved"}
    return {"success": False, "message": "Failed to save settings"}

# --------------------------

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # Allow all for dev
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

PROJECTS_DIR = os.path.join(os.path.dirname(__file__), "projects")
if not os.path.exists(PROJECTS_DIR):
    os.makedirs(PROJECTS_DIR)

API_URL = "http://localhost:8000"

# Serve static files for video preview
app.mount("/projects_static", StaticFiles(directory=PROJECTS_DIR), name="projects_static")


class ProjectCreate(BaseModel):
    name: str

class ProcessRequest(BaseModel):
    youtube_url: Optional[str] = None
    local_file: Optional[str] = None
    ai_model: Optional[str] = "google/gemini-3-flash-preview"
    resolution: Optional[str] = "1080"
    auto_intro: Optional[bool] = False
    source_watermark: Optional[str] = "none"
    gemini_api_key: Optional[str] = None
    elevenlabs_api_key: Optional[str] = None

# ...

@app.post("/projects/{project_name}/upload_source")
async def upload_source(project_name: str, file: UploadFile = File(...)):
    """Upload a local video file to the project directory."""
    project_path = os.path.join(PROJECTS_DIR, project_name)
    if not os.path.exists(project_path):
        raise HTTPException(status_code=404, detail="Project not found")
        
    # Sanitize filename
    safe_filename = "".join(x for x in file.filename if (x.isalnum() or x in "._- "))
    file_path = os.path.join(project_path, safe_filename)
    
    try:
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
            
        return {"filename": safe_filename, "path": file_path}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")

class ClipRequest(BaseModel):
    clips: List[dict] # [{start, end, title}, ...]

@app.get("/")
def read_root():
    return {"message": "Klipah API is running"}

@app.post("/test-ai")
def test_ai_connection(request: dict = Body(...), model: Optional[str] = "google/gemini-3-flash-preview"):
    return test_connection(api_key=request.get("gemini_api_key"), model=model)

@app.get("/ai-models")
def get_ai_models(gemini_api_key: Optional[str] = None):
    """Get list of available Gemini models."""
    return list_gemini_models(api_key=gemini_api_key)

@app.get("/projects")
def list_projects():
    """List all existing projects."""
    if not os.path.exists(PROJECTS_DIR):
        return []
    try:
        projects = [d for d in os.listdir(PROJECTS_DIR) if os.path.isdir(os.path.join(PROJECTS_DIR, d))]
        # Sort by modification time (newest first)
        projects.sort(key=lambda d: os.path.getmtime(os.path.join(PROJECTS_DIR, d)), reverse=True)
        return projects
    except Exception as e:
        logging.error(f"Error listing projects: {e}")
        return []

@app.get("/projects/{project_name}/check")
def check_project_state(project_name: str):
    """Check what files exist in the project directory for resuming."""
    project_path = os.path.join(PROJECTS_DIR, project_name)
    if not os.path.exists(project_path):
        raise HTTPException(status_code=404, detail="Project not found")
        
    try:
        files = os.listdir(project_path)
        
        # Check for source video
        source_files = [f for f in files if f.lower().endswith(('.mp4', '.mkv', '.webm')) and not f.startswith(('raw_', 'crop_', 'FINAL'))]
        has_source = len(source_files) > 0
        source_filename = source_files[0] if has_source else None
        
        has_transcript = "transcript.json" in files
        has_highlights = "highlights.json" in files
        
        highlights = []
        if has_highlights:
            with open(os.path.join(project_path, "highlights.json"), 'r', encoding='utf-8') as f:
                highlights = json.load(f)

        return {
            "name": project_name,
            "hasSource": has_source,
            "hasTranscript": has_transcript,
            "hasHighlights": has_highlights,
            "sourceFilename": source_filename,
            "highlights": highlights
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error checking project: {str(e)}")

@app.post("/projects")
def create_project(project: ProjectCreate):
    """Create a new project folder. Appends _n if name exists."""
    safe_name = "".join(x for x in project.name if (x.isalnum() or x in "._- ")).strip()
    project_path = os.path.join(PROJECTS_DIR, safe_name)
    
    if os.path.exists(project_path):
        # Find unique name with suffix
        counter = 1
        new_name = f"{safe_name}_{counter}"
        new_path = os.path.join(PROJECTS_DIR, new_name)
        while os.path.exists(new_path):
            counter += 1
            new_name = f"{safe_name}_{counter}"
            new_path = os.path.join(PROJECTS_DIR, new_name)
        
        safe_name = new_name
        project_path = new_path
    
    os.makedirs(project_path)
    return {"message": "Project created", "name": safe_name, "path": project_path}

from fastapi.responses import StreamingResponse
import json
import time

@app.post("/projects/{project_name}/process")
def process_source(project_name: str, request: ProcessRequest):
    """
    Stream progress updates as JSON lines.
    Final line will contain the result data.
    """
    project_path = os.path.join(PROJECTS_DIR, project_name)
    if not os.path.exists(project_path):
        raise HTTPException(status_code=404, detail="Project not found")

    def process_generator():
        try:
            yield json.dumps({"type": "log", "msg": f"Starting processing for project: {project_name}..."}) + "\n"
            
            video_path = None
            if request.youtube_url:
                yield json.dumps({"type": "log", "msg": f"Processing YouTube URL: {request.youtube_url}"}) + "\n"
                
                # 1. TRY FETCHING EXISTING TRANSCRIPT (INSTANT)
                yield json.dumps({"type": "log", "msg": "Checking for existing captions on YouTube..."}) + "\n"
                transcript_data = get_youtube_transcript(request.youtube_url)
                
                if transcript_data:
                    yield json.dumps({"type": "log", "msg": "Captions found! Using YouTube transcript."}) + "\n"
                else:
                    yield json.dumps({"type": "log", "msg": "No existing captions. Will transcribe audio after download."}) + "\n"

                # 2. DOWNLOAD VIDEO (WITH PROGRESS)
                progress_queue = queue.Queue()
                def dl_callback(msg):
                    progress_queue.put(msg)
                
                dl_thread = threading.Thread(
                    target=lambda: progress_queue.put(
                        download_video(request.youtube_url, output_dir=project_path, resolution=request.resolution or "1080", progress_callback=dl_callback)
                    )
                )
                dl_thread.start()
                
                while dl_thread.is_alive() or not progress_queue.empty():
                    try:
                        item = progress_queue.get(timeout=0.2)
                        if isinstance(item, str):
                            yield json.dumps({"type": "log", "msg": item}) + "\n"
                        else:
                            # Result tuple (video_path, title)
                            video_path, title = item
                    except queue.Empty:
                        continue
                    except Exception as e:
                        yield json.dumps({"type": "log", "msg": f"Error during download: {str(e)}"}) + "\n"
                        break

                if not video_path:
                    yield json.dumps({"type": "error", "msg": "Video download failed."}) + "\n"
                    return

                # 3. FETCH CHANNEL INFO
                yield json.dumps({"type": "log", "msg": "Fetching channel info for credits..."}) + "\n"
                try:
                    channel_info = get_channel_info(request.youtube_url, output_dir=project_path)
                    channel_info_path = os.path.join(project_path, "channel_info.json")
                    with open(channel_info_path, 'w', encoding='utf-8') as f:
                        json.dump(channel_info, f, indent=2)
                    yield json.dumps({"type": "log", "msg": f"Channel detected: {channel_info['channel_name']}"}) + "\n"
                except Exception as ch_err:
                    logging.warning(f"Could not fetch channel info: {ch_err}")

                # 4. TRANSCRIBE IF NEEDED
                if not transcript_data:
                    yield json.dumps({"type": "log", "msg": "Starting Audio Transcription (Whisper)..."}) + "\n"
                    transcript_data = transcribe_audio_file(video_path)
                    yield json.dumps({"type": "log", "msg": "Transcription complete."}) + "\n"

            elif request.local_file:
                 yield json.dumps({"type": "log", "msg": f"Using uploaded file: {request.local_file}"}) + "\n"
                 potential_path = os.path.join(project_path, request.local_file)
                 if os.path.exists(potential_path):
                     video_path = potential_path
                 else:
                     yield json.dumps({"type": "error", "msg": f"File not found: {request.local_file}"}) + "\n"
                     return

                 yield json.dumps({"type": "log", "msg": "Starting Audio Transcription (Whisper)..."}) + "\n"
                 transcript_data = transcribe_audio_file(video_path)
                 yield json.dumps({"type": "log", "msg": "Transcription complete."}) + "\n"

            if not video_path or not transcript_data:
                 yield json.dumps({"type": "error", "msg": "Failed to obtain video or transcript"}) + "\n"
                 return
            
            # Save Transcript
            transcript_path = os.path.join(project_path, "transcript.json")
            save_transcript(transcript_data, transcript_path)
            yield json.dumps({"type": "log", "msg": f"Transcript saved to {transcript_path}"}) + "\n"

            try:
                # Use selected AI model if provided
                selected_ai_model = request.ai_model or "google/gemini-3-flash-preview"
                yield json.dumps({"type": "log", "msg": f"AI analyzing with model: {selected_ai_model}..."}) + "\n"
                
                highlights = extract_highlights(transcript_path, api_key=request.gemini_api_key, model=selected_ai_model)
                yield json.dumps({"type": "log", "msg": f"AI identified {len(highlights)} potential moments."}) + "\n"
                
                # Fetch total video duration to bound highlights safely
                import subprocess
                cmd_dur = [
                    "ffprobe", "-v", "error", "-show_entries", "format=duration",
                    "-of", "default=noprint_wrappers=1:nokey=1", video_path
                ]
                total_duration = float(subprocess.check_output(cmd_dur).decode().strip())
                
                # Add 3 second buffer to the end of short clips to prevent sudden cut-offs
                for h in highlights:
                    try:
                        start_t = float(h['start'])
                        end_t = float(h['end'])
                        clip_dur = end_t - start_t
                        if clip_dur < 60.0:
                            new_end = min(end_t + 3.0, total_duration)
                            h['end'] = round(new_end, 2)
                    except:
                        pass
                        
            except Exception as ai_err:
                 yield json.dumps({"type": "error", "msg": f"AI Analysis failed: {str(ai_err)}"}) + "\n"
                 return
            
            highlight_path = os.path.join(project_path, "highlights.json")
            with open(highlight_path, 'w', encoding='utf-8') as f:
                json.dump(highlights, f, indent=4)

            # Auto-Clip Highlights
            yield json.dumps({"type": "log", "msg": "Auto-clipping highlights for preview..."}) + "\n"
            
            output_clips_dir = os.path.join(project_path, "clips")
            if not os.path.exists(output_clips_dir):
                os.makedirs(output_clips_dir)
            
            final_highlights = []
            for i, highlight in enumerate(highlights):
                try:
                    start = float(highlight['start'])
                    end = float(highlight['end'])
                    title = highlight['title']
                    
                    safe_title = "".join(x for x in title if (x.isalnum() or x in "._- ")).strip().replace(" ", "_")
                    out_name = f"clip_{i+1}_{safe_title}.mp4"
                    out_path = os.path.join(output_clips_dir, out_name)
                    
                    # Store relative path for frontend access via /projects_static
                    # Format: project_name/clips/clip_name.mp4
                    rel_path = f"{project_name}/clips/{out_name}"
                    
                    yield json.dumps({"type": "log", "msg": f"Clipping: {title} ({end-start:.1f}s)..."}) + "\n"
                    success = clip_video(video_path, start, end, out_path)
                    
                    if success:
                        highlight['clip_url'] = f"{API_URL}/projects_static/{rel_path}"
                        final_highlights.append(highlight)
                except Exception as clip_err:
                    logging.error(f"Failed to clip {highlight.get('title')}: {clip_err}")

            # Final Result
            result_data = {
                "message": "Processing complete",
                "video_path": video_path,
                "transcript_path": transcript_path,
                "highlights": final_highlights
            }
            yield json.dumps({"type": "result", "data": result_data}) + "\n"

        except Exception as e:
            yield json.dumps({"type": "error", "msg": f"Critical Error: {str(e)}"}) + "\n"
            logging.error(f"Processing failed: {e}")

    return StreamingResponse(process_generator(), media_type="application/x-ndjson")

class FinalizeRequest(BaseModel):
    clip_indices: List[int] # Match FE parameter name
    transcription_mode: Optional[str] = "ai"  # 'original' or 'ai'
    gemini_api_key: Optional[str] = None
    elevenlabs_api_key: Optional[str] = None
    auto_intro: Optional[bool] = False
    use_transition: Optional[bool] = False
    source_watermark: Optional[str] = "none"

@app.post("/projects/{project_name}/finalize")
async def finalize_clips(project_name: str, request: FinalizeRequest = Body(...)):
    """
    Finalize selected clips:
    1. Delete unselected ones.
    2. For selected ones, process into 9:16 with auto-centering and subtitles.
    """
    project_path = os.path.join(PROJECTS_DIR, project_name)
    clips_dir = os.path.join(project_path, "clips")
    final_dir = os.path.join(project_path, "final")
    
    if not os.path.exists(clips_dir):
        raise HTTPException(status_code=404, detail="Clips directory not found")
        
    if not os.path.exists(final_dir):
        os.makedirs(final_dir)
        
    # Load transcript and highlights to get segment data for subtitles
    transcript_path = os.path.join(project_path, "transcript.json")
    with open(transcript_path, 'r', encoding='utf-8') as f:
        transcript_data = json.load(f)
    
    highlight_path = os.path.join(project_path, "highlights.json")
    with open(highlight_path, 'r', encoding='utf-8') as f:
        highlights_data = json.load(f)

    def finalize_generator():
        try:
            # 1. Cleanup
            yield json.dumps({"type": "log", "msg": "Cleaning up unselected resources..."}) + "\n"
            # Use numeric sorting to ensure index 1 comes before index 10
            all_clip_files = sorted(
                [f for f in os.listdir(clips_dir) if f.startswith("clip_")],
                key=lambda x: int(x.split('_')[1].split('.')[0])
            )
            
            kept_clips = []
            for i, clip_file in enumerate(all_clip_files):
                if i not in request.clip_indices:
                    try:
                        os.remove(os.path.join(clips_dir, clip_file))
                    except Exception as e:
                        logging.error(f"Failed to delete {clip_file}: {e}")
                else:
                    kept_clips.append((i, clip_file))
            
            # 2. Process Selected Clips
            yield json.dumps({"type": "log", "msg": f"Processing {len(kept_clips)} selected clips into 9:16 vertical format..."}) + "\n"
            
            # Find source video again
            source_video = None
            for f in os.listdir(project_path):
                if f.endswith(('.mp4', '.mkv', '.mov')) and not f.startswith("clip_") and "final" not in f:
                    source_video = os.path.join(project_path, f)
                    break
            
            if not source_video:
                yield json.dumps({"type": "error", "msg": "Source video not found for final processing."}) + "\n"
                return

            from src.subtitler import generate_srt
            from src.audio_transcriber import transcribe_audio_file
            from src.video_clipper import clip_video, burn_subtitles, concatenate_videos, concatenate_videos_with_transition
            from src.face_cropper import dynamic_face_crop_9x16
            from src.intro_generator import generate_intro
            
            # Load channel info for credit overlay (if available)
            channel_name = None
            logo_path = None
            channel_info_path = os.path.join(project_path, "channel_info.json")
            if os.path.exists(channel_info_path):
                try:
                    with open(channel_info_path, 'r', encoding='utf-8') as f:
                        channel_info = json.load(f)
                    channel_name = channel_info.get('channel_name')
                    logo_path = channel_info.get('avatar_path')
                    yield json.dumps({"type": "log", "msg": f"Using creator credit: {channel_name}"}) + "\n"
                except Exception as ch_err:
                    logging.warning(f"Could not load channel info: {ch_err}")
            
            final_results = []
            for i, clip_name in kept_clips:
                try:
                    highlight = highlights_data[i]
                    title = highlight['title']
                    start = float(highlight['start'])
                    end = float(highlight['end'])
                    
                    yield json.dumps({"type": "log", "msg": f"--- Processing Clip {i+1}: '{title}' ---"}) + "\n"

                    # Setup Paths
                    safe_title = "".join(x for x in title if (x.isalnum() or x in "._- ")).strip().replace(" ", "_")
                    raw_clip_path = os.path.join(final_dir, f"raw_{i}_{safe_title}.mp4")
                    cropped_path = os.path.join(final_dir, f"crop_{i}_{safe_title}.mp4")
                    srt_path = os.path.join(final_dir, f"subtitles_{i}.srt")
                    # Simplified name for the intermediate final file
                    temp_final_name = f"final_tmp_{i}_{safe_title}.mp4"
                    final_path = os.path.join(final_dir, temp_final_name)
                    
                    # --- STEP 1: CLIP RAW ---
                    yield json.dumps({"type": "log", "msg": f"[{title}] Step 1/4: Clipping raw segments..."}) + "\n"
                    success_clip = clip_video(source_video, start, end, raw_clip_path) # No crop/subs here
                    if not success_clip:
                        yield json.dumps({"type": "log", "msg": f"[{title}] Raw clipping failed. Skipping clip."}) + "\n"
                        continue
                    
                    # --- STEP 2: FACE CENTER 9:16 ---
                    yield json.dumps({"type": "log", "msg": f"[{title}] Step 2/4: AI Auto-Centering (9:16)..."}) + "\n"
                    try:
                        dynamic_face_crop_9x16(raw_clip_path, cropped_path)
                    except Exception as e:
                        yield json.dumps({"type": "log", "msg": f"[{title}] Face cropping error: {str(e)}"}) + "\n"
                        logging.error(f"Face cropping failed: {e}")
                        continue
                    
                    # --- STEP 3: WHISPER TRANSCRIBE ---
                    try: # This try block was missing in the original code for transcription
                        yield json.dumps({"type": "log", "msg": f"[{title}] Step 3/4: Transcribing audio for subtitles..."}) + "\n"
                        clip_transcript = transcribe_audio_file(raw_clip_path)
                        generate_srt(clip_transcript['segments'], srt_path, start_offset=0)
                    except Exception as e:
                        yield json.dumps({"type": "log", "msg": f"[{title}] Transcription error: {str(e)}"}) + "\n"
                        logging.error(f"Transcription failed: {e}")
                        continue
                    
                    # --- STEP 4: BURN SUBTITLES + WATERMARK ---
                    yield json.dumps({"type": "log", "msg": f"[{title}] Step 4/5: Burning premium subtitles..."}) + "\n"
                    
                    subtitled_path = os.path.join(final_dir, f"subtitled_{i}_{safe_title}.mp4")
                    
                    wm_pos = request.source_watermark or "none"
                    yield json.dumps({"type": "log", "msg": f"[{title}] Watermark: pos={wm_pos}, channel={channel_name}, logo={logo_path}"}) + "\n"
                    
                    success_burn = burn_subtitles(
                        cropped_path, raw_clip_path, srt_path, subtitled_path,
                        channel_name=channel_name, logo_path=logo_path,
                        watermark_position=wm_pos
                    )
                    
                    if not success_burn:
                         yield json.dumps({"type": "log", "msg": f"[{title}] Subtitle burn failed. Skipping clip."}) + "\n"
                         continue
                    
                    yield json.dumps({"type": "log", "msg": f"[{title}] Subtitles burned OK. File exists: {os.path.exists(subtitled_path)}"}) + "\n"

                    # --- STEP 5: INTRO GENERATION (optional) ---
                    if request.auto_intro:
                        yield json.dumps({"type": "log", "msg": f"[{title}] Step 5/5: Generating Auto-Intro..."}) + "\n"
                        intro_path = os.path.join(final_dir, f"intro_{i}.mp4")
                        success_intro = False
                        try:
                            success_intro = generate_intro(cropped_path, title, intro_path, elevenlabs_api_key=request.elevenlabs_api_key)
                        except Exception as e:
                            logging.error(f"Intro gen failed: {e}")
                            yield json.dumps({"type": "log", "msg": f"[{title}] Intro error: {str(e)}"}) + "\n"
                        
                        if success_intro:
                            # Merge Intro + Subtitled Clip
                            if request.use_transition:
                                src_dir = os.path.join(os.path.dirname(__file__), "src")
                                transition_mp4 = os.path.join(src_dir, "transition.mp4")
                                transition_mp3 = os.path.join(src_dir, "transition.mp3")
                                
                                yield json.dumps({"type": "log", "msg": f"[{title}] Merging with Greenscreen Transition..."}) + "\n"
                                success_concat = concatenate_videos_with_transition(
                                    [intro_path, subtitled_path], 
                                    final_path, 
                                    transition_mp4, 
                                    transition_mp3
                                )
                            else:
                                success_concat = concatenate_videos([intro_path, subtitled_path], final_path)
                                
                            if not success_concat:
                                 # Fallback to no intro
                                 logging.warning("Concatenation failed, pushing subtitled clip as final")
                                 if os.path.exists(final_path): os.remove(final_path)
                                 shutil.copy2(subtitled_path, final_path)
                        else:
                            yield json.dumps({"type": "log", "msg": f"[{title}] Intro gen failed. Using subtitled clip as final."}) + "\n"
                            shutil.copy2(subtitled_path, final_path)
                    else:
                        # Auto-Intro is OFF — just use the subtitled clip directly
                        yield json.dumps({"type": "log", "msg": f"[{title}] Step 5/5: Auto-Intro disabled. Using subtitled clip as final."}) + "\n"
                        shutil.copy2(subtitled_path, final_path)
                    
                    yield json.dumps({"type": "log", "msg": f"[{title}] Final file exists: {os.path.exists(final_path)}, size: {os.path.getsize(final_path) if os.path.exists(final_path) else 0} bytes"}) + "\n"

                    if os.path.exists(final_path):
                        # Use clean name for final move destination
                        clean_filename = f"{safe_title}.mp4"
                        dest_path = os.path.join(project_path, clean_filename)
                        
                        # Move to project root now or later? Let's do it now to be sure
                        if os.path.exists(dest_path): os.remove(dest_path)
                        shutil.move(final_path, dest_path)
                        
                        rel_path = f"{project_name}/{clean_filename}"
                        final_results.append({
                            "title": title,
                            "url": f"{API_URL}/projects_static/{rel_path}",
                            "id": i
                        })
                        yield json.dumps({"type": "log", "msg": f"[{title}] Done! Successfully finalized."}) + "\n"
                        
                        # Immediate cleanup of this clip's intermediates
                        try:
                            for tmp in [raw_clip_path, cropped_path, srt_path, subtitled_path, intro_path]:
                                if tmp and os.path.exists(tmp): os.remove(tmp)
                        except: pass
                    else:
                         yield json.dumps({"type": "log", "msg": f"[{title}] Final file missing?"}) + "\n"
                except Exception as loop_err:
                     yield json.dumps({"type": "log", "msg": f"Critical error on clip {i+1}: {str(loop_err)}"}) + "\n"
                     logging.error(f"Loop error: {loop_err}")
            
            # --- FINAL CLEANUP OF PROJECT FOLDER ---
            yield json.dumps({"type": "log", "msg": "Final cleaning... Removing intermediate files."}) + "\n"
            try:
                # Delete 'clips' folder
                clips_path = os.path.join(project_path, "clips")
                if os.path.exists(clips_path): shutil.rmtree(clips_path)
                
                # Delete 'final' folder
                if os.path.exists(final_dir): shutil.rmtree(final_dir)
                
                # Delete JSON metadata and source videos
                for f in os.listdir(project_path):
                    # Get just the filename from the final_results URLs for comparison
                    final_result_filenames = [os.path.basename(r['url']) for r in final_results]
                    
                    # Check if it's a file and not one of the final result videos
                    f_path = os.path.join(project_path, f)
                    if os.path.isfile(f_path) and f not in final_result_filenames:
                        # Delete if it's a JSON, or a video that's not a final result
                        if f.endswith('.json') or f.endswith(('.mp4', '.mkv', '.mov')):
                            os.remove(f_path)
            except Exception as cleanup_err:
                logging.error(f"Post-process cleanup failed: {cleanup_err}")

            yield json.dumps({"type": "result", "data": {"message": "Finalization complete", "clips": final_results}}) + "\n"

        except Exception as e:
            yield json.dumps({"type": "error", "msg": f"Finalization failed: {str(e)}"}) + "\n"
            logging.error(f"Finalization failed: {e}")

    return StreamingResponse(finalize_generator(), media_type="application/x-ndjson")

@app.post("/projects/{project_name}/clip")
def generate_clips(project_name: str, request: ClipRequest):
    project_path = os.path.join(PROJECTS_DIR, project_name)
    if not os.path.exists(project_path):
        raise HTTPException(status_code=404, detail="Project not found")
        
    # Find source video. 
    # We can assume it's in the folder. Let's look for mp4/mkv.
    # Or strict way: store metadata. 
    # Lazy way: search folder.
    source_video = None
    for f in os.listdir(project_path):
        if f.endswith(('.mp4', '.mkv', '.mov')) and not f.startswith("clip_"):
            source_video = os.path.join(project_path, f)
            break
            
    if not source_video:
        raise HTTPException(status_code=404, detail="Source video not found in project")

    output_dir = os.path.join(project_path, "clips")
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    results = []
    for i, clip in enumerate(request.clips):
        start = float(clip['start'])
        end = float(clip['end'])
        title = clip['title']
        
        safe_title = "".join(x for x in title if (x.isalnum() or x in "._- "))
        out_name = f"clip_{i+1}_{safe_title}.mp4"
        out_path = os.path.join(output_dir, out_name)
        
        success = clip_video(source_video, start, end, out_path)
        results.append({"title": title, "path": out_path, "success": success})

    return {"message": "Clipping complete", "output_dir": output_dir, "results": results}

# ==========================================
# DEV-ONLY: Test Finalize Pipeline with dummy.mp4
# TODO: Remove before production
# ==========================================
class DevTestRequest(BaseModel):
    elevenlabs_api_key: Optional[str] = None

@app.post("/dev/test-finalize")
def dev_test_finalize(request: DevTestRequest = Body(...)):
    """
    DEV ONLY: Test the finalize pipeline using dummy.mp4.
    Generates 3 clips with different configs:
      1. Clip + Subtitle only
      2. Auto Intro + Transition + Subtitle
      3. Watermark + Intro + Transition + Subtitle
    """
    backend_dir = os.path.dirname(__file__)
    dummy_video = os.path.join(backend_dir, "dummy.mp4")
    
    if not os.path.exists(dummy_video):
        raise HTTPException(status_code=404, detail="dummy.mp4 not found in Backend directory")
    
    project_name = "_dev_test"
    project_path = os.path.join(PROJECTS_DIR, project_name)
    
    # 3 test configurations
    test_configs = [
        {
            "label": "1️⃣ Clip + Subtitle Only",
            "safe_title": "Clip_Subtitle_Only",
            "watermark": "none",
            "auto_intro": False,
            "use_transition": False,
        },
        {
            "label": "2️⃣ Intro + Transition + Subtitle",
            "safe_title": "Intro_Transition_Subtitle",
            "watermark": "none",
            "auto_intro": True,
            "use_transition": True,
        },
        {
            "label": "3️⃣ Watermark + Intro + Transition + Subtitle",
            "safe_title": "Watermark_Intro_Transition_Sub",
            "watermark": "center",
            "auto_intro": True,
            "use_transition": True,
        },
    ]
    
    def test_generator():
        try:
            yield json.dumps({"type": "log", "msg": "🧪 [DEV] Starting 3-clip finalize test..."}) + "\n"
            
            # 1. Setup project
            if os.path.exists(project_path):
                shutil.rmtree(project_path)
            os.makedirs(project_path)
            
            final_dir = os.path.join(project_path, "final")
            os.makedirs(final_dir)
            
            # 2. Copy dummy video
            source_video = os.path.join(project_path, "dummy_source.mp4")
            shutil.copy2(dummy_video, source_video)
            yield json.dumps({"type": "log", "msg": "📁 Copied dummy.mp4 as source"}) + "\n"
            
            # 3. Get video duration
            import subprocess as sp
            cmd_dur = [
                "ffprobe", "-v", "error", "-show_entries", "format=duration",
                "-of", "default=noprint_wrappers=1:nokey=1", source_video
            ]
            total_duration = float(sp.check_output(cmd_dur).decode().strip())
            yield json.dumps({"type": "log", "msg": f"📏 Video duration: {total_duration:.1f}s"}) + "\n"
            
            # 4. Generate dummy transcript with word-level timestamps
            clip_end = min(15.0, total_duration)
            dummy_words = ["This", "is", "a", "dummy", "test", "for", "the", "finalize", "pipeline"]
            word_dur = clip_end / len(dummy_words)
            
            segments = [{
                "start": 0.0,
                "end": clip_end,
                "text": " ".join(dummy_words),
                "words": [
                    {
                        "start": round(i * word_dur, 2),
                        "end": round((i + 1) * word_dur, 2),
                        "word": w
                    }
                    for i, w in enumerate(dummy_words)
                ]
            }]
            yield json.dumps({"type": "log", "msg": "📝 Generated dummy transcript with word timestamps"}) + "\n"
            
            # Imports
            from src.subtitler import generate_srt
            from src.video_clipper import clip_video, burn_subtitles, concatenate_videos_with_transition, concatenate_videos
            from src.face_cropper import dynamic_face_crop_9x16
            from src.intro_generator import generate_intro
            
            src_dir = os.path.join(backend_dir, "src")
            transition_mp4 = os.path.join(src_dir, "transition.mp4")
            transition_mp3 = os.path.join(src_dir, "transition.mp3")
            
            # --- SHARED: Raw clip + Face crop (same for all 3) ---
            raw_clip_path = os.path.join(final_dir, "raw_shared.mp4")
            cropped_path = os.path.join(final_dir, "crop_shared.mp4")
            srt_path = os.path.join(final_dir, "subtitles_shared.srt")
            
            yield json.dumps({"type": "log", "msg": "✂️ Clipping raw segment..."}) + "\n"
            success = clip_video(source_video, 0.0, clip_end, raw_clip_path)
            if not success:
                yield json.dumps({"type": "error", "msg": "Raw clipping failed"}) + "\n"
                return
            
            yield json.dumps({"type": "log", "msg": "🎯 AI Auto-Centering (9:16)..."}) + "\n"
            try:
                dynamic_face_crop_9x16(raw_clip_path, cropped_path)
            except Exception as e:
                yield json.dumps({"type": "log", "msg": f"⚠️ Face crop error: {e}. Using raw clip."}) + "\n"
                shutil.copy2(raw_clip_path, cropped_path)
            
            yield json.dumps({"type": "log", "msg": "📝 Generating SRT..."}) + "\n"
            generate_srt(segments, srt_path, start_offset=0)
            
            yield json.dumps({"type": "log", "msg": "✅ Shared base ready (raw + crop + SRT)"}) + "\n"
            yield json.dumps({"type": "log", "msg": "═══════════════════════════════════════"}) + "\n"
            
            # --- LOOP: 3 different configs ---
            final_results = []
            
            for idx, cfg in enumerate(test_configs):
                label = cfg["label"]
                safe_title = cfg["safe_title"]
                wm_pos = cfg["watermark"]
                do_intro = cfg["auto_intro"]
                do_transition = cfg["use_transition"]
                
                yield json.dumps({"type": "log", "msg": f"\n{label}"}) + "\n"
                yield json.dumps({"type": "log", "msg": f"  Config: watermark={wm_pos}, intro={do_intro}, transition={do_transition}"}) + "\n"
                
                try:
                    # Burn subtitles (+ optional watermark)
                    subtitled_path = os.path.join(final_dir, f"subtitled_{idx}_{safe_title}.mp4")
                    
                    channel_name = "@TestChannel" if wm_pos != "none" else None
                    
                    yield json.dumps({"type": "log", "msg": f"  🔥 Burning subtitles..." + (f" + watermark ({wm_pos})" if wm_pos != "none" else "")}) + "\n"
                    success_burn = burn_subtitles(
                        cropped_path, raw_clip_path, srt_path, subtitled_path,
                        channel_name=channel_name, logo_path=None,
                        watermark_position=wm_pos
                    )
                    
                    if not success_burn:
                        yield json.dumps({"type": "log", "msg": f"  ❌ Subtitle burn failed! Skipping."}) + "\n"
                        continue
                    yield json.dumps({"type": "log", "msg": f"  ✅ Subtitles burned"}) + "\n"
                    
                    # The "current best" file for this clip
                    current_file = subtitled_path
                    
                    # Optional: Intro generation
                    if do_intro:
                        intro_path = os.path.join(final_dir, f"intro_{idx}.mp4")
                        yield json.dumps({"type": "log", "msg": f"  🎬 Generating Auto-Intro (ElevenLabs TTS)..."}) + "\n"
                        
                        success_intro = False
                        try:
                            success_intro = generate_intro(
                                cropped_path, "Dummy Test Clip", intro_path,
                                elevenlabs_api_key=request.elevenlabs_api_key
                            )
                        except Exception as e:
                            yield json.dumps({"type": "log", "msg": f"  ⚠️ Intro error: {str(e)}"}) + "\n"
                        
                        if success_intro:
                            # Merge intro + clip
                            merged_path = os.path.join(final_dir, f"merged_{idx}_{safe_title}.mp4")
                            
                            if do_transition:
                                yield json.dumps({"type": "log", "msg": f"  🌀 Merging with greenscreen transition..."}) + "\n"
                                success_merge = concatenate_videos_with_transition(
                                    [intro_path, subtitled_path],
                                    merged_path,
                                    transition_mp4,
                                    transition_mp3
                                )
                            else:
                                yield json.dumps({"type": "log", "msg": f"  🔗 Concatenating intro + clip..."}) + "\n"
                                success_merge = concatenate_videos([intro_path, subtitled_path], merged_path)
                            
                            if success_merge:
                                current_file = merged_path
                                yield json.dumps({"type": "log", "msg": f"  ✅ Intro + clip merged"}) + "\n"
                            else:
                                yield json.dumps({"type": "log", "msg": f"  ⚠️ Merge failed. Using subtitled clip only."}) + "\n"
                        else:
                            yield json.dumps({"type": "log", "msg": f"  ⚠️ Intro gen failed. Using subtitled clip only."}) + "\n"
                    
                    # Move to project root
                    clean_filename = f"{safe_title}.mp4"
                    dest_path = os.path.join(project_path, clean_filename)
                    if os.path.exists(dest_path):
                        os.remove(dest_path)
                    shutil.copy2(current_file, dest_path)
                    
                    rel_path = f"{project_name}/{clean_filename}"
                    final_results.append({
                        "title": f"{label}",
                        "url": f"{API_URL}/projects_static/{rel_path}",
                        "id": idx
                    })
                    yield json.dumps({"type": "log", "msg": f"  ✅ Done: {clean_filename}"}) + "\n"
                    yield json.dumps({"type": "log", "msg": "───────────────────────────────────────"}) + "\n"
                    
                except Exception as clip_err:
                    yield json.dumps({"type": "log", "msg": f"  ❌ Error on {label}: {str(clip_err)}"}) + "\n"
                    logging.error(f"Dev test clip error: {clip_err}")
            
            # Cleanup intermediates
            try:
                if os.path.exists(final_dir):
                    shutil.rmtree(final_dir)
            except:
                pass
            
            yield json.dumps({"type": "log", "msg": f"\n🎉 DEV TEST COMPLETE! Generated {len(final_results)}/3 clips."}) + "\n"
            yield json.dumps({"type": "result", "data": {"message": "Dev test complete", "clips": final_results}}) + "\n"
        
        except Exception as e:
            yield json.dumps({"type": "error", "msg": f"Dev test failed: {str(e)}"}) + "\n"
            logging.error(f"Dev test failed: {e}")
    
    return StreamingResponse(test_generator(), media_type="application/x-ndjson")

# Serve UI (after API routes)
FE_DIST = os.path.join(os.path.dirname(__file__), "frontend_dist")
if os.path.exists(FE_DIST):
    app.mount("/", StaticFiles(directory=FE_DIST, html=True), name="ui")
    
    # Catch-all for SPA routing (must be last)
    @app.get("/{full_path:path}")
    async def serve_spa(full_path: str):
        index_file = os.path.join(FE_DIST, "index.html")
        if os.path.exists(index_file):
            from fastapi.responses import FileResponse
            return FileResponse(index_file)
        return {"message": "Klipah API is running"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
