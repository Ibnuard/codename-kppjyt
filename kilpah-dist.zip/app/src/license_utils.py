import hmac
import hashlib
import os
from datetime import datetime

SECRET_KEY = b"Klipah-Global-Secret-Key-2026"

def verify_license(license_key: str):
    """
    Verifies if a license key is valid and not expired.
    Format: YYYYMMDD-SIGNATURE
    """
    if not license_key or "-" not in license_key:
        return False, "Invalid format"

    try:
        expiry_str, signature = license_key.split("-")
        
        # 1. Verify Signature
        expected_sig = hmac.new(SECRET_KEY, expiry_str.encode(), hashlib.sha256).hexdigest()[:12].upper()
        if signature.upper() != expected_sig:
            return False, "Tampered license key"

        # 2. Check Date
        expiry_date = datetime.strptime(expiry_str, "%Y%m%d")
        if datetime.now() > expiry_date:
            return False, f"License expired on {expiry_date.strftime('%Y-%m-%d')}"

        return True, "Active"
    except Exception as e:
        return False, f"Verification error: {str(e)}"

def check_license_file(app_root: str):
    """Checks for license.txt in the application root."""
    license_path = os.path.join(app_root, "license.txt")
    if not os.path.exists(license_path):
        return False, "License file missing"

    try:
        with open(license_path, "r") as f:
            key = f.read().strip()
        return verify_license(key)
    except Exception as e:
        return False, f"Read error: {str(e)}"
